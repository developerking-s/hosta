import { useI18n } from '@/lib/i18n';
import { Link } from 'react-router-dom';
import { Check } from 'lucide-react';

interface PricingCardProps {
  name: string;
  price: string;
  ram: string;
  cpu: string;
  storage: string;
  apps: string;
  features: string[];
  popular?: boolean;
}

const PricingCard = ({ name, price, ram, cpu, storage, apps, features, popular }: PricingCardProps) => {
  const { t } = useI18n();

  return (
    <div className={`relative surface-card p-6 flex flex-col ${popular ? 'border-primary/50 glow-sm' : ''}`}>
      {popular && (
        <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full gradient-primary text-xs font-semibold text-primary-foreground">
          {t.plans.popular}
        </div>
      )}

      <div className="mb-6">
        <h3 className="text-xl font-bold font-display mb-1">{name}</h3>
        <div className="flex items-baseline gap-1">
          <span className="text-3xl font-bold font-display">{price === '0' ? 'Free' : `R$${price}`}</span>
          {price !== '0' && <span className="text-sm text-muted-foreground">{t.plans.month}</span>}
        </div>
      </div>

      <div className="space-y-3 mb-6 text-sm">
        <div className="flex justify-between py-2 border-b border-border">
          <span className="text-muted-foreground">{t.plans.ram}</span>
          <span className="font-medium">{ram}</span>
        </div>
        <div className="flex justify-between py-2 border-b border-border">
          <span className="text-muted-foreground">{t.plans.cpu}</span>
          <span className="font-medium">{cpu}</span>
        </div>
        <div className="flex justify-between py-2 border-b border-border">
          <span className="text-muted-foreground">{t.plans.storage}</span>
          <span className="font-medium">{storage}</span>
        </div>
        <div className="flex justify-between py-2 border-b border-border">
          <span className="text-muted-foreground">{t.plans.apps}</span>
          <span className="font-medium">{apps}</span>
        </div>
      </div>

      <div className="space-y-2 mb-6 flex-1">
        {features.map((f, i) => (
          <div key={i} className="flex items-center gap-2 text-sm">
            <Check className="h-4 w-4 text-primary shrink-0" />
            <span className="text-muted-foreground">{f}</span>
          </div>
        ))}
      </div>

      <Link
        to="/register"
        className={`block text-center py-3 rounded-xl font-semibold text-sm transition-all ${
          popular
            ? 'gradient-primary text-primary-foreground glow-sm hover:opacity-90'
            : 'bg-secondary text-foreground hover:bg-secondary/80 border border-border'
        }`}
      >
        {t.plans.select}
      </Link>
    </div>
  );
};

export default PricingCard;
