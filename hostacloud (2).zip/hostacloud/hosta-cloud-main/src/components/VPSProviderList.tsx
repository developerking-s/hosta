import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Loader2, ExternalLink } from 'lucide-react';
import { VPSProvider } from '@/services/vps';

interface VPSProviderListProps {
  providers?: VPSProvider[];
  loading?: boolean;
  onProviderClick?: (provider: VPSProvider) => void;
}

export function VPSProviderList({ 
  providers: initialProviders = [],
  loading: initialLoading = false,
  onProviderClick 
}: VPSProviderListProps) {
  const [providers, setProviders] = useState<VPSProvider[]>(initialProviders);
  const [loading, setLoading] = useState(initialLoading);
  const [error, setError] = useState<string | null>(null);

  const getVpsService = async () => {
    const { vpsService } = await import('@/services/vps');
    return vpsService;
  };

  const loadProviders = async () => {
    try {
      setLoading(true);
      setError(null);
      const service = await getVpsService();
      const providerList = await service.getProviders();
      setProviders(providerList);
    } catch (err: any) {
      setError(err.message || 'Failed to load providers');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (initialProviders.length === 0) {
      loadProviders();
    }
  }, []);

  const getRatingColor = (rating: number) => {
    if (rating >= 4.5) return 'bg-green-100 text-green-800';
    if (rating >= 4.0) return 'bg-blue-100 text-blue-800';
    return 'bg-yellow-100 text-yellow-800';
  };

  if (loading && providers.length === 0) {
    return (
      <Card>
        <CardContent className="pt-6 text-center">
          <Loader2 className="h-6 w-6 animate-spin mx-auto mb-2" />
          <p className="text-muted-foreground">Loading providers...</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <div>
        <h3 className="text-lg font-semibold">Free VPS Providers</h3>
        <p className="text-sm text-muted-foreground">Connect to free hosting providers</p>
      </div>

      {error && (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="pt-6 text-red-700">{error}</CardContent>
        </Card>
      )}

      {providers.length === 0 ? (
        <Card>
          <CardContent className="pt-6 text-center text-muted-foreground">
            No providers available at this moment.
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2">
          {providers.map((provider) => (
            <Card 
              key={provider.id} 
              className="cursor-pointer hover:border-primary transition-colors"
              onClick={() => onProviderClick?.(provider)}
            >
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-lg">{provider.name}</CardTitle>
                    <CardDescription>{provider.country}</CardDescription>
                  </div>
                  <div className={`px-2 py-1 rounded text-xs font-semibold ${getRatingColor(provider.rating)}`}>
                    ⭐ {provider.rating}
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-muted-foreground">{provider.description}</p>
                
                <div className="space-y-2">
                  <h4 className="text-sm font-semibold">Specifications:</h4>
                  <div className="grid gap-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">CPU:</span>
                      <span className="font-medium">{provider.specs.cpu}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Memory:</span>
                      <span className="font-medium">{provider.specs.memory}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Disk:</span>
                      <span className="font-medium">{provider.specs.disk}</span>
                    </div>
                  </div>
                </div>

                <Button 
                  className="w-full"
                  onClick={(e) => {
                    e.stopPropagation();
                    window.open(provider.url, '_blank');
                  }}
                >
                  <ExternalLink className="mr-2 h-4 w-4" />
                  Visit Provider
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
