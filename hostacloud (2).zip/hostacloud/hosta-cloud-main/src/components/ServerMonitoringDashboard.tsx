import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Loader2 } from 'lucide-react';
import { ServerMonitoring } from '@/services/vps';

interface ServerMonitoringProps {
  autoRefresh?: boolean;
  refreshInterval?: number;
}

export function ServerMonitoringDashboard({ 
  autoRefresh = true, 
  refreshInterval = 30000 
}: ServerMonitoringProps) {
  const [servers, setServers] = useState<ServerMonitoring[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const getVpsService = async () => {
    const { vpsService } = await import('@/services/vps');
    return vpsService;
  };

  const loadMonitoringData = async () => {
    try {
      setLoading(true);
      setError(null);
      const service = await getVpsService();
      const data = await service.getMonitoringData();
      setServers(data);
    } catch (err: any) {
      setError(err.message || 'Failed to load monitoring data');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadMonitoringData();

    if (autoRefresh) {
      const interval = setInterval(loadMonitoringData, refreshInterval);
      return () => clearInterval(interval);
    }
  }, [autoRefresh, refreshInterval]);

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
  };

  if (loading && servers.length === 0) {
    return (
      <Card>
        <CardContent className="pt-6 text-center">
          <Loader2 className="h-6 w-6 animate-spin mx-auto mb-2" />
          <p className="text-muted-foreground">Loading monitoring data...</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <div>
        <h3 className="text-lg font-semibold">Server Monitoring</h3>
        <p className="text-sm text-muted-foreground">Real-time resource usage across your servers</p>
      </div>

      {error && (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="pt-6 text-red-700">{error}</CardContent>
        </Card>
      )}

      {servers.length === 0 ? (
        <Card>
          <CardContent className="pt-6 text-center text-muted-foreground">
            No servers to monitor. Add servers to get started.
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4">
          {servers.map((server) => (
            <Card key={server.id}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-base">{server.name}</CardTitle>
                    <CardDescription>{server.ip}</CardDescription>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className={`px-2 py-1 rounded text-xs font-semibold ${
                      server.status === 'online'
                        ? 'bg-green-100 text-green-800'
                        : 'bg-red-100 text-red-800'
                    }`}>
                      {server.status === 'online' ? '🟢 Online' : '🔴 Offline'}
                    </div>
                    <div className="border border-current rounded px-2 py-1 text-xs font-semibold">
                      {server.provider}
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* CPU Usage */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium">CPU Usage</span>
                    <span className="text-sm font-semibold">{server.cpu.used}%</span>
                  </div>
                  <Progress value={server.cpu.used} className="h-2" />
                </div>

                {/* Memory Usage */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium">Memory Usage</span>
                    <span className="text-sm font-semibold">
                      {Math.round((server.memory.used / server.memory.total) * 100)}%
                    </span>
                  </div>
                  <Progress 
                    value={(server.memory.used / server.memory.total) * 100} 
                    className="h-2" 
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    {formatBytes(server.memory.used)} / {formatBytes(server.memory.total)}
                  </p>
                </div>

                {/* Disk Usage */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium">Disk Usage</span>
                    <span className="text-sm font-semibold">
                      {Math.round((server.disk.used / server.disk.total) * 100)}%
                    </span>
                  </div>
                  <Progress 
                    value={(server.disk.used / server.disk.total) * 100} 
                    className="h-2" 
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    {formatBytes(server.disk.used)} / {formatBytes(server.disk.total)}
                  </p>
                </div>

                {/* Additional Info */}
                <div className="flex justify-between text-sm text-muted-foreground pt-2 border-t">
                  <span>⏱️ Uptime: {server.uptime}</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
