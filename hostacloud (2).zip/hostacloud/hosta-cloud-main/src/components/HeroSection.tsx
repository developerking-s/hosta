import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowRight, Terminal, Sparkles } from 'lucide-react';
import { useState, useEffect } from 'react';

const floatingDots = Array.from({ length: 12 }, (_, i) => ({
  id: i,
  x: Math.random() * 100,
  y: Math.random() * 100,
  size: Math.random() * 6 + 3,
  duration: Math.random() * 20 + 15,
  delay: Math.random() * 5,
}));

const languages = [
  { name: 'Node.js', icon: '⬢', color: 'text-emerald-400' },
  { name: 'Python', icon: '🐍', color: 'text-blue-400' },
  { name: 'Go', icon: '◆', color: 'text-cyan-400' },
  { name: 'Java', icon: '☕', color: 'text-orange-400' },
  { name: 'Ruby', icon: '💎', color: 'text-red-400' },
  { name: 'PHP', icon: '🐘', color: 'text-indigo-400' },
  { name: 'Rust', icon: '⚙', color: 'text-amber-400' },
  { name: 'Docker', icon: '🐳', color: 'text-sky-400' },
];

const HeroSection = () => {
  const [appsCount, setAppsCount] = useState(0);

  useEffect(() => {
    const target = 1247;
    const interval = setInterval(() => {
      setAppsCount(p => {
        if (p >= target) { clearInterval(interval); return target; }
        return p + Math.ceil((target - p) / 10);
      });
    }, 30);
    return () => clearInterval(interval);
  }, []);

  return (
    <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden">
      {/* Animated floating dots */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {floatingDots.map(dot => (
          <motion.div
            key={dot.id}
            className="absolute rounded-full bg-primary/40"
            style={{ width: dot.size, height: dot.size, left: `${dot.x}%`, top: `${dot.y}%` }}
            animate={{
              y: [0, -30, 10, -20, 0],
              x: [0, 15, -10, 5, 0],
              opacity: [0.2, 0.6, 0.3, 0.5, 0.2],
            }}
            transition={{ duration: dot.duration, repeat: Infinity, delay: dot.delay, ease: 'easeInOut' }}
          />
        ))}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[600px] h-[600px] rounded-full bg-primary/8 blur-[200px]" />
        <div className="absolute bottom-0 left-1/4 w-[400px] h-[400px] rounded-full bg-accent/5 blur-[150px]" />
      </div>

      <div className="container mx-auto px-4 relative z-10 text-center py-20">
        {/* Badge */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-primary/30 bg-primary/5 mb-8"
        >
          <Sparkles className="h-3.5 w-3.5 text-primary" />
          <span className="text-xs font-medium text-primary">Hospede sua aplicação gratuitamente!</span>
          <ArrowRight className="h-3 w-3 text-primary" />
        </motion.div>

        {/* Main title */}
        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.1 }}
          className="text-5xl md:text-7xl lg:text-8xl font-bold font-display tracking-tight mb-6"
        >
          Hosta
        </motion.h1>

        <motion.h2
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="text-xl md:text-3xl font-bold font-display mb-6"
        >
          <span className="gradient-text">Ajudando Projetos. Com uma infraestrutura de qualidade.</span>
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="text-base md:text-lg text-muted-foreground max-w-2xl mx-auto mb-10 leading-relaxed"
        >
          Hospedagem simplificada para desenvolvedores. Deploy rápido, preços acessíveis e 
          suporte para suas linguagens favoritas.
        </motion.p>

        {/* CTAs */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-3 mb-16"
        >
          <Link
            to="/register"
            className="group inline-flex items-center gap-2 px-8 py-4 rounded-xl gradient-primary text-primary-foreground font-bold text-base glow transition-all hover:opacity-90"
          >
            <Terminal className="h-4 w-4" />
            Começar Agora
            <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
          </Link>
          <Link
            to="/docs"
            className="inline-flex items-center gap-2 px-8 py-4 rounded-xl border border-border bg-card/50 text-foreground font-medium text-base hover:bg-card transition-all"
          >
            Explorar Docs
          </Link>
        </motion.div>

        {/* Language icons */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="flex flex-wrap items-center justify-center gap-6 md:gap-10"
        >
          {languages.map((lang, i) => (
            <motion.div
              key={lang.name}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.7 + i * 0.05 }}
              className="flex flex-col items-center gap-1.5 group cursor-default"
            >
              <span className={`text-2xl md:text-3xl opacity-40 group-hover:opacity-80 transition-opacity`}>{lang.icon}</span>
              <span className="text-[10px] font-mono text-muted-foreground/50 group-hover:text-muted-foreground transition-colors">{lang.name}</span>
            </motion.div>
          ))}
        </motion.div>

        {/* Stats bar */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1 }}
          className="flex flex-wrap items-center justify-center gap-8 md:gap-16 mt-16 pt-8 border-t border-border/30"
        >
          {[
            { value: appsCount.toLocaleString() + '+', label: 'Apps hospedados' },
            { value: '99.97%', label: 'Uptime' },
            { value: '<2s', label: 'Deploy time' },
            { value: '24/7', label: 'Monitoramento' },
          ].map((stat, i) => (
            <div key={i} className="text-center">
              <div className="text-xl md:text-2xl font-bold font-display">{stat.value}</div>
              <div className="text-[11px] text-muted-foreground font-mono uppercase tracking-wider">{stat.label}</div>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default HeroSection;
