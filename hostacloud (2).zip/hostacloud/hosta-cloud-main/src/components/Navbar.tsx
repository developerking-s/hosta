import { Link, useLocation } from 'react-router-dom';
import { useI18n, Locale } from '@/lib/i18n';
import { useAuth } from '@/lib/auth';
import { Menu, X, Globe, Server, ChevronDown } from 'lucide-react';
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const localeLabels: Record<Locale, string> = { pt: 'PT', en: 'EN', es: 'ES' };

const Navbar = () => {
  const { t, locale, setLocale } = useI18n();
  const { user } = useAuth();
  const location = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [langOpen, setLangOpen] = useState(false);

  const links = [
    { to: '/', label: t.nav.home },
    { to: '/plans', label: t.nav.plans },
    { to: '/pterodactyl', label: '🚀 Control Panel', badge: true },
    { to: '/docs', label: 'Docs' },
    { to: '/status', label: 'Status' },
    { to: '/blog', label: 'Blog' },
    { to: '/about', label: t.nav.about },
  ];

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 border-b border-border/50 bg-background/70 backdrop-blur-xl">
      <div className="container mx-auto flex h-14 items-center justify-between px-4">
        <Link to="/" className="flex items-center gap-2 group">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg gradient-primary transition-all group-hover:glow-sm">
            <Server className="h-4 w-4 text-primary-foreground" />
          </div>
          <span className="text-lg font-bold font-display">Hosta</span>
        </Link>

        {/* Desktop nav */}
        <div className="hidden lg:flex items-center gap-0.5">
          {links.map(link => (
            <Link
              key={link.to}
              to={link.to}
              className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all relative ${
                isActive(link.to)
                  ? 'bg-primary/10 text-primary'
                  : 'text-muted-foreground hover:text-foreground hover:bg-secondary/50'
              }`}
            >
              {link.label}
              {(link as any).badge && (
                <span className="absolute -top-1 -right-1 h-2 w-2 bg-yellow-500 rounded-full animate-pulse"></span>
              )}
            </Link>
          ))}
        </div>

        <div className="hidden lg:flex items-center gap-2">
          <div className="relative">
            <button
              onClick={() => setLangOpen(!langOpen)}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs text-muted-foreground hover:text-foreground hover:bg-secondary/50 transition-colors"
            >
              <Globe className="h-3.5 w-3.5" />
              {localeLabels[locale]}
              <ChevronDown className="h-3 w-3" />
            </button>
            <AnimatePresence>
              {langOpen && (
                <motion.div
                  initial={{ opacity: 0, y: -4 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -4 }}
                  className="absolute right-0 mt-1 w-20 rounded-lg border border-border bg-card p-1 shadow-xl"
                >
                  {(['pt', 'en', 'es'] as Locale[]).map(l => (
                    <button
                      key={l}
                      onClick={() => { setLocale(l); setLangOpen(false); }}
                      className={`w-full text-left px-2.5 py-1 rounded-md text-xs transition-colors ${
                        locale === l ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:bg-secondary'
                      }`}
                    >
                      {localeLabels[l]}
                    </button>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {user ? (
            <Link
              to="/dashboard"
              className="px-4 py-1.5 rounded-lg text-sm font-semibold gradient-primary text-primary-foreground glow-sm transition-all hover:opacity-90"
            >
              Dashboard
            </Link>
          ) : (
            <>
              <Link to="/login" className="px-3 py-1.5 rounded-lg text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
                {t.nav.login}
              </Link>
              <Link to="/register" className="px-4 py-1.5 rounded-lg text-sm font-semibold gradient-primary text-primary-foreground glow-sm transition-all hover:opacity-90">
                {t.nav.register}
              </Link>
            </>
          )}
        </div>

        <button onClick={() => setMobileOpen(!mobileOpen)} className="lg:hidden p-2 text-muted-foreground">
          {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>

      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="lg:hidden border-t border-border bg-background overflow-hidden"
          >
            <div className="p-4 space-y-1">
              {links.map(link => (
                <Link key={link.to} to={link.to} onClick={() => setMobileOpen(false)}
                  className={`block px-3 py-2.5 rounded-lg text-sm font-medium transition-colors relative ${isActive(link.to) ? 'bg-primary/10 text-primary' : 'text-muted-foreground hover:bg-secondary'}`}>
                  {link.label}
                  {(link as any).badge && (
                    <span className="absolute top-1 right-2 h-2 w-2 bg-yellow-500 rounded-full animate-pulse"></span>
                  )}
                </Link>
              ))}
              <div className="flex gap-2 pt-3 border-t border-border mt-3">
                {(['pt', 'en', 'es'] as Locale[]).map(l => (
                  <button key={l} onClick={() => setLocale(l)}
                    className={`px-3 py-1.5 rounded-md text-xs ${locale === l ? 'bg-primary text-primary-foreground' : 'bg-secondary text-muted-foreground'}`}>
                    {localeLabels[l]}
                  </button>
                ))}
              </div>
              <div className="flex gap-2 pt-3">
                {user ? (
                  <Link to="/dashboard" onClick={() => setMobileOpen(false)} className="flex-1 text-center px-4 py-2.5 rounded-lg text-sm gradient-primary text-primary-foreground font-semibold">
                    Dashboard
                  </Link>
                ) : (
                  <>
                    <Link to="/login" onClick={() => setMobileOpen(false)} className="flex-1 text-center px-4 py-2.5 rounded-lg text-sm border border-border text-foreground">
                      {t.nav.login}
                    </Link>
                    <Link to="/register" onClick={() => setMobileOpen(false)} className="flex-1 text-center px-4 py-2.5 rounded-lg text-sm gradient-primary text-primary-foreground font-semibold">
                      {t.nav.register}
                    </Link>
                  </>
                )}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

export default Navbar;
