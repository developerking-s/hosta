import { motion } from 'framer-motion';
import { Quote } from 'lucide-react';

const PhilosophySection = () => (
  <section className="py-24">
    <div className="container mx-auto px-4">
      {/* Founder quote card */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="relative bg-card border border-border rounded-3xl p-10 md:p-16 overflow-hidden"
      >
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/3" />
        <div className="relative z-10 max-w-3xl mx-auto text-center">
          <Quote className="h-8 w-8 text-primary/30 mx-auto mb-6" />
          <blockquote className="text-xl md:text-2xl font-display font-bold leading-relaxed mb-8">
            Na Hosta, tornamos suas ideias a realidade com qualidade e segurança.
            <span className="gradient-text"> Cada desenvolvedor merece hospedagem que se importa.</span>
          </blockquote>
          <div className="flex items-center justify-center gap-4">
            <div className="w-12 h-12 rounded-full gradient-primary flex items-center justify-center text-primary-foreground font-bold font-display text-lg">
              H
            </div>
            <div className="text-left">
              <div className="font-bold font-display text-sm">King</div>
              <div className="text-xs text-muted-foreground">Fundador da Hosta Cloud</div>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  </section>
);

export default PhilosophySection;
