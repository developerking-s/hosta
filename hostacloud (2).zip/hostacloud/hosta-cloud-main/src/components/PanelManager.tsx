import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Loader2, Plus, Trash2, RefreshCw } from 'lucide-react';
import { PanelInstance } from '@/services/pterodactyl';

interface PanelManagerProps {
  onPanelSelect?: (panel: PanelInstance) => void;
  onPanelsLoaded?: (panels: PanelInstance[]) => void;
}

export function PanelManager({ onPanelSelect, onPanelsLoaded }: PanelManagerProps) {
  const [panels, setPanels] = useState<PanelInstance[]>([]);
  const [loading, setLoading] = useState(false);
  const [newPanelUrl, setNewPanelUrl] = useState('');
  const [newPanelName, setNewPanelName] = useState('');
  const [error, setError] = useState<string | null>(null);

  // Dynamic import to avoid circular dependency
  const getPterodactylService = async () => {
    const { pterodactylService } = await import('@/services/pterodactyl');
    return pterodactylService;
  };

  const loadPanels = async () => {
    try {
      setLoading(true);
      setError(null);
      const service = await getPterodactylService();
      const panelList = await service.getPanels();
      setPanels(panelList);
      onPanelsLoaded?.(panelList);
    } catch (err: any) {
      setError(err.message || 'Failed to load panels');
    } finally {
      setLoading(false);
    }
  };

  const addPanel = async () => {
    if (!newPanelUrl.trim()) {
      setError('Please enter a panel URL');
      return;
    }

    try {
      setLoading(true);
      setError(null);
      const service = await getPterodactylService();
      const newPanel = await service.addPanel(newPanelUrl, newPanelName);
      setPanels([...panels, newPanel]);
      setNewPanelUrl('');
      setNewPanelName('');
    } catch (err: any) {
      setError(err.message || 'Failed to add panel');
    } finally {
      setLoading(false);
    }
  };

  const deletePanel = async (instanceId: string) => {
    try {
      setLoading(true);
      const service = await getPterodactylService();
      await service.deletePanel(instanceId);
      setPanels(panels.filter((p) => p.id !== instanceId));
    } catch (err: any) {
      setError(err.message || 'Failed to delete panel');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadPanels();
  }, []);

  return (
    <div className="space-y-6">
      {/* Add New Panel */}
      <Card>
        <CardHeader>
          <CardTitle>Add Pterodactyl Panel</CardTitle>
          <CardDescription>Connect to a Pterodactyl panel instance</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4">
            <Input
              placeholder="Panel URL (e.g., https://panel.pterodactyl.io)"
              value={newPanelUrl}
              onChange={(e) => setNewPanelUrl(e.target.value)}
              disabled={loading}
            />
            <Input
              placeholder="Panel Name (optional)"
              value={newPanelName}
              onChange={(e) => setNewPanelName(e.target.value)}
              disabled={loading}
            />
          </div>
          <Button onClick={addPanel} disabled={loading} className="w-full">
            {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Plus className="mr-2 h-4 w-4" />}
            Add Panel
          </Button>
          {error && <p className="text-sm text-red-500">{error}</p>}
        </CardContent>
      </Card>

      {/* Panels List */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold">Connected Panels</h3>
          <Button
            variant="outline"
            size="sm"
            onClick={loadPanels}
            disabled={loading}
          >
            {loading ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <RefreshCw className="h-4 w-4" />
            )}
          </Button>
        </div>

        {panels.length === 0 ? (
          <Card>
            <CardContent className="pt-6 text-center text-muted-foreground">
              No panels connected yet. Add one to get started.
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4">
            {panels.map((panel) => (
              <Card key={panel.id} className="cursor-pointer hover:border-primary" onClick={() => onPanelSelect?.(panel)}>
                <CardContent className="pt-6">
                  <div className="flex items-start justify-between">
                    <div className="space-y-2 flex-1">
                      <div className="flex items-center gap-2">
                        <h4 className="font-semibold">{panel.name}</h4>
                      <div className={`px-2 py-1 rounded text-xs font-semibold ${
                        panel.status === 'online' 
                          ? 'bg-green-100 text-green-800' 
                          : 'bg-red-100 text-red-800'
                      }`}>
                        {panel.status === 'online' ? '🟢 Online' : '🔴 Offline'}
                      </div>
                      </div>
                      <p className="text-sm text-muted-foreground break-all">{panel.url}</p>
                      {panel.stats && (
                        <div className="flex gap-4 text-sm pt-2">
                          <span>🖥️ Servers: {panel.stats.servers}</span>
                          <span>🌐 Nodes: {panel.stats.nodes}</span>
                          <span>👥 Users: {panel.stats.users}</span>
                        </div>
                      )}
                    </div>
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        deletePanel(panel.id);
                      }}
                      disabled={loading}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
