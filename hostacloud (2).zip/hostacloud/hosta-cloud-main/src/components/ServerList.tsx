import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Loader2, RefreshCw } from 'lucide-react';
import { Server } from '@/services/pterodactyl';

interface ServerListProps {
  panelId: string;
  onServerSelect?: (server: Server) => void;
}

export function ServerList({ panelId, onServerSelect }: ServerListProps) {
  const [servers, setServers] = useState<Server[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const getPterodactylService = async () => {
    const { pterodactylService } = await import('@/services/pterodactyl');
    return pterodactylService;
  };

  const loadServers = async () => {
    try {
      setLoading(true);
      setError(null);
      const service = await getPterodactylService();
      const serverList = await service.getServers(panelId);
      setServers(serverList);
    } catch (err: any) {
      setError(err.message || 'Failed to load servers');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadServers();
  }, [panelId]);

  if (loading && servers.length === 0) {
    return (
      <Card>
        <CardContent className="pt-6 text-center">
          <Loader2 className="h-6 w-6 animate-spin mx-auto mb-2" />
          <p className="text-muted-foreground">Loading servers...</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">Servers</h3>
        <Button
          variant="outline"
          size="sm"
          onClick={loadServers}
          disabled={loading}
        >
          {loading ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            <RefreshCw className="h-4 w-4" />
          )}
        </Button>
      </div>

      {error && (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="pt-6 text-red-700">{error}</CardContent>
        </Card>
      )}

      {servers.length === 0 ? (
        <Card>
          <CardContent className="pt-6 text-center text-muted-foreground">
            No servers found on this panel.
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4">
          {servers.map((server) => (
            <Card
              key={server.uuid}
              className="cursor-pointer hover:border-primary"
              onClick={() => onServerSelect?.(server)}
            >
              <CardContent className="pt-6">
                <div className="flex items-start justify-between">
                  <div className="space-y-2 flex-1">
                    <div className="flex items-center gap-2">
                      <h4 className="font-semibold">{server.name}</h4>
                      <div className={`px-2 py-1 rounded text-xs font-semibold ${
                        !server.suspended
                          ? 'bg-green-100 text-green-800'
                          : 'bg-red-100 text-red-800'
                      }`}>
                        {!server.suspended ? '✓ Active' : '⚠️ Suspended'}
                      </div>
                    </div>
                    <p className="text-sm text-muted-foreground">UUID: {server.uuid.substring(0, 8)}...</p>
                    {server.limits && (
                      <div className="flex gap-4 text-sm pt-2">
                        <span>💾 {server.limits.memory}MB RAM</span>
                        <span>💿 {server.limits.disk}MB Disk</span>
                        <span>⚙️ {server.limits.cpu}% CPU</span>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
