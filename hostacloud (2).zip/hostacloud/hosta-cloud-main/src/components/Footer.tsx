import { Link } from 'react-router-dom';
import { useI18n } from '@/lib/i18n';
import { Server } from 'lucide-react';

const Footer = () => {
  const { t } = useI18n();

  return (
    <footer className="border-t border-border bg-background">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg gradient-primary">
                <Server className="h-4 w-4 text-primary-foreground" />
              </div>
              <span className="text-lg font-bold font-display">Hosta</span>
            </div>
            <p className="text-sm text-muted-foreground">{t.footer.description}</p>
          </div>

          <div>
            <h4 className="font-semibold font-display text-sm mb-3">{t.footer.product}</h4>
            <div className="space-y-2">
              <Link to="/plans" className="block text-sm text-muted-foreground hover:text-foreground transition-colors">{t.nav.plans}</Link>
              <Link to="/support" className="block text-sm text-muted-foreground hover:text-foreground transition-colors">{t.nav.support}</Link>
            </div>
          </div>

          <div>
            <h4 className="font-semibold font-display text-sm mb-3">{t.footer.company}</h4>
            <div className="space-y-2">
              <Link to="/about" className="block text-sm text-muted-foreground hover:text-foreground transition-colors">{t.nav.about}</Link>
              <Link to="/support" className="block text-sm text-muted-foreground hover:text-foreground transition-colors">{t.nav.support}</Link>
            </div>
          </div>

          <div>
            <h4 className="font-semibold font-display text-sm mb-3">{t.footer.legal}</h4>
            <div className="space-y-2">
              <Link to="/terms" className="block text-sm text-muted-foreground hover:text-foreground transition-colors">{t.legal.terms}</Link>
              <Link to="/legal" className="block text-sm text-muted-foreground hover:text-foreground transition-colors">{t.legal.privacy}</Link>
            </div>
          </div>
        </div>

        <div className="border-t border-border mt-8 pt-6 text-center">
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} Hosta. {t.footer.rights}
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
