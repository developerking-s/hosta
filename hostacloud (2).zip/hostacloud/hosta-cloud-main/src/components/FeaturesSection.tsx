import { motion } from 'framer-motion';
import { Shield, Zap, Terminal, Clock, Code2, Eye, Cpu, HardDrive, Globe, Rocket, Bot, Plug } from 'lucide-react';

const FeaturesSection = () => {
  const mainFeatures = [
    { icon: Rocket, title: 'Deploy Em Segundos', desc: 'Faça deploy com nosso painel completo e organizado.', gradient: 'from-primary/20 to-accent/10' },
    { icon: Cpu, title: 'Infraestrutura Otima', desc: 'Estabilidade otima e qualidade no seu serviço', gradient: 'from-emerald-500/20 to-cyan-500/10' },
    { icon: Shield, title: 'Segurança Perfeita', desc: 'Proteção de qualidade com 24/7', gradient: 'from-blue-500/20 to-indigo-500/10' },
  ];

  const gridFeatures = [
    { icon: Clock, title: 'Uptime 24/7', desc: 'Seus apps nunca dormem.' },
    { icon: Zap, title: 'Auto-restart', desc: 'Caiu? Volta sozinho.' },
    { icon: Terminal, title: 'Logs em tempo real', desc: 'Console ao vivo no painel.' },
    { icon: Eye, title: 'Monitoring', desc: 'RAM, CPU, disco — tudo visível.' },
    { icon: Code2, title: 'Git Deploy', desc: 'Push no repo = deploy automático.' },
    { icon: HardDrive, title: 'Isolamento', desc: 'Cada app em container dedicado.' },
  ];

const appTypes = [
    { icon: Bot, name: 'Discord Bots', desc: 'Node.js, Python, Go. 24/7.', tag: 'Popular' },
    { icon: Globe, name: 'Sites & Apps', desc: 'React, Next.js, Vue, HTML.' },
    { icon: Plug, name: 'APIs & Backend', desc: 'REST, GraphQL, webhooks.' },
  ];
  
  return (
    <section className="py-24 relative">
      <div className="container mx-auto px-4">
        {/* Why Hosta */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <span className="text-xs font-mono text-primary uppercase tracking-widest mb-3 block">Por que a Hosta?</span>
          <h2 className="text-3xl md:text-5xl font-bold font-display">
            Hospedagem simples, pronta para crescer com você.
          </h2>
        </motion.div>

        {/* 3 main feature cards */}
        <div className="grid md:grid-cols-3 gap-6 mb-24">
          {mainFeatures.map((f, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="group relative bg-card border border-border rounded-2xl p-8 hover:border-primary/40 transition-all overflow-hidden"
            >
              <div className={`absolute inset-0 bg-gradient-to-br ${f.gradient} opacity-0 group-hover:opacity-100 transition-opacity`} />
              <div className="relative z-10">
                <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center mb-5 group-hover:bg-primary/20 transition-colors">
                  <f.icon className="h-7 w-7 text-primary" />
                </div>
                <h3 className="text-xl font-bold font-display mb-2">{f.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{f.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>

        {/* App types */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <span className="text-xs font-mono text-primary uppercase tracking-widest mb-3 block">O que hospedamos</span>
          <h2 className="text-3xl md:text-4xl font-bold font-display">
            Feito pra rodar, <span className="text-muted-foreground">não pra enfeitar.</span>
          </h2>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-4 mb-24">
          {appTypes.map((app, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 15 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08 }}
              className="relative bg-card border border-border rounded-2xl p-6 hover:border-primary/30 transition-all group"
            >
              {app.tag && (
                <span className="absolute top-4 right-4 text-[9px] font-mono uppercase tracking-wider text-primary bg-primary/10 px-2 py-0.5 rounded-full">
                  {app.tag}
                </span>
              )}
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                <app.icon className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-lg font-bold font-display mb-1">{app.name}</h3>
              <p className="text-sm text-muted-foreground">{app.desc}</p>
            </motion.div>
          ))}
        </div>

        {/* Technical grid */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <span className="text-xs font-mono text-primary uppercase tracking-widest mb-3 block">Recursos</span>
          <h2 className="text-3xl md:text-4xl font-bold font-display">
            Infraestrutura <span className="text-muted-foreground">que funciona.</span>
          </h2>
        </motion.div>

        <div className="grid grid-cols-2 lg:grid-cols-3 gap-px bg-border rounded-2xl overflow-hidden">
          {gridFeatures.map((f, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.05 }}
              className="bg-card p-6 md:p-8 hover:bg-card/80 transition-colors group"
            >
              <f.icon className="h-5 w-5 text-primary mb-3 group-hover:scale-110 transition-transform" />
              <h3 className="text-sm md:text-base font-bold font-display mb-1">{f.title}</h3>
              <p className="text-xs md:text-sm text-muted-foreground">{f.desc}</p>
            </motion.div>
          ))}
        </div>

        {/* Tech stack */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-16 text-center"
        >
          <p className="text-xs font-mono text-muted-foreground uppercase tracking-widest mb-6">Compatível com</p>
          <div className="flex flex-wrap items-center justify-center gap-2">
            {['Node.js', 'Python', 'Go', 'Java', 'Ruby', 'PHP', 'Rust', 'Docker', 'Discord.js', 'Discord.py', 'Next.js', 'React', 'Vue', 'Express', 'Fastify'].map(tech => (
              <span key={tech} className="px-3 py-1.5 rounded-lg bg-card border border-border text-xs font-mono text-muted-foreground hover:text-foreground hover:border-primary/30 transition-all cursor-default">
                {tech}
              </span>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default FeaturesSection;
