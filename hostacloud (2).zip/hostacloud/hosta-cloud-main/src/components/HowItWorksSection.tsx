import { motion } from 'framer-motion';
import { UserPlus, Settings, Upload, BarChart3 } from 'lucide-react';

const steps = [
  { num: '01', icon: UserPlus, title: 'Crie sua conta', desc: 'Registro em 10 segundos. Sem cartão de crédito.' },
  { num: '02', icon: Settings, title: 'Configure o servidor', desc: 'Escolha o tipo, linguagem e recursos.' },
  { num: '03', icon: Upload, title: 'Faça deploy', desc: 'Envie o código via painel ou Git push.' },
  { num: '04', icon: BarChart3, title: 'Monitore', desc: 'Logs, métricas e alertas em tempo real.' },
];

const HowItWorksSection = () => (
  <section className="py-24 relative overflow-hidden">
    <div className="absolute inset-0 pointer-events-none">
      <div className="absolute top-1/2 left-0 w-[400px] h-[400px] rounded-full bg-primary/3 blur-[150px]" />
    </div>
    <div className="container mx-auto px-4 relative z-10">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="text-center mb-16"
      >
        <span className="text-xs font-mono text-primary uppercase tracking-widest mb-3 block">Como funciona</span>
        <h2 className="text-3xl md:text-5xl font-bold font-display">
          4 passos. <span className="text-muted-foreground">Nenhuma complicação.</span>
        </h2>
      </motion.div>

      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
        {steps.map((step, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1 }}
            className="bg-card border border-border rounded-2xl p-6 hover:border-primary/30 transition-all group text-center"
          >
            <span className="text-3xl font-bold font-display text-primary/15 group-hover:text-primary/30 transition-colors block mb-4">{step.num}</span>
            <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4 mx-auto group-hover:bg-primary/20 transition-colors">
              <step.icon className="h-6 w-6 text-primary" />
            </div>
            <h3 className="text-base font-bold font-display mb-1">{step.title}</h3>
            <p className="text-sm text-muted-foreground">{step.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default HowItWorksSection;
