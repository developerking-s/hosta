import React, { createContext, useContext, useState, useCallback } from 'react';

export type Locale = 'pt' | 'en' | 'es';

const translations = {
  pt: {
    nav: { home: 'Início', plans: 'Planos', support: 'Suporte', about: 'Sobre', login: 'Entrar', register: 'Criar Conta', dashboard: 'Dashboard' },
    hero: { title: 'Hospede seus bots e sites com', highlight: 'simplicidade', subtitle: 'Plataforma de hospedagem profissional para Discord Bots, Sites e Aplicações. Infraestrutura confiável que nunca dorme.', cta: 'Começar Grátis', ctaSecondary: 'Ver Planos' },
    features: { title: 'Tudo que você precisa', subtitle: 'Infraestrutura completa para seus projetos', uptime: '99.9% Uptime', uptimeDesc: 'Servidores monitorados 24/7 com redundância automática', deploy: 'Deploy Instantâneo', deployDesc: 'Envie seu código e veja rodando em segundos', languages: 'Multi-linguagem', languagesDesc: 'Suporte a Node.js, Python, Go, e muito mais', security: 'Segurança', securityDesc: 'SSL gratuito, DDoS protection e backups automáticos', files: 'Editor de Arquivos', filesDesc: 'Edite seus arquivos diretamente pelo painel', api: 'API Completa', apiDesc: 'API RESTful para automação e integrações' },
    plans: { title: 'Planos', subtitle: 'Escolha o plano ideal para seu projeto', free: 'Free', basic: 'Basic', standard: 'Standard', pro: 'Pro', advanced: 'Advanced', month: '/mês', current: 'Plano Atual', select: 'Selecionar', popular: 'Popular', ram: 'RAM', cpu: 'vCPU', storage: 'Armazenamento', apps: 'Aplicações' },
    auth: { login: 'Entrar', register: 'Criar Conta', email: 'Email', password: 'Senha', confirmPassword: 'Confirmar Senha', name: 'Nome', forgotPassword: 'Esqueceu a senha?', noAccount: 'Não tem conta?', hasAccount: 'Já tem conta?', orContinue: 'Ou continue com' },
    dashboard: { myApps: 'Minhas Aplicações', newApp: 'Nova Aplicação', settings: 'Configurações', billing: 'Faturamento', profile: 'Perfil', logout: 'Sair', status: 'Status', online: 'Online', offline: 'Offline', starting: 'Iniciando', ram: 'RAM', cpu: 'CPU', upload: 'Upload', files: 'Arquivos', console: 'Console', start: 'Iniciar', stop: 'Parar', restart: 'Reiniciar', delete: 'Excluir', deploy: 'Deploy' },
    support: { title: 'Suporte', subtitle: 'Estamos aqui para ajudar', discord: 'Discord', discordDesc: 'Entre no nosso servidor Discord', docs: 'Documentação', docsDesc: 'Consulte nossa documentação completa', email: 'Email', emailDesc: 'Envie um email para nossa equipe', faq: 'FAQ', faqTitle: 'Perguntas Frequentes' },
    about: { title: 'Sobre Nós', subtitle: 'Conheça a Hosta', mission: 'Nossa Missão', missionText: 'Democratizar o acesso à hospedagem de qualidade para desenvolvedores de todos os níveis.' },
    legal: { title: 'Informações Legais', terms: 'Termos de Serviço', privacy: 'Política de Privacidade', cookies: 'Política de Cookies' },
    footer: { description: 'Plataforma de hospedagem profissional para bots e sites.', product: 'Produto', company: 'Empresa', legal: 'Legal', rights: 'Todos os direitos reservados.' },
  },
  en: {
    nav: { home: 'Home', plans: 'Plans', support: 'Support', about: 'About', login: 'Login', register: 'Sign Up', dashboard: 'Dashboard' },
    hero: { title: 'Host your bots and sites with', highlight: 'simplicity', subtitle: 'Professional hosting platform for Discord Bots, Websites and Applications. Reliable infrastructure that never sleeps.', cta: 'Start Free', ctaSecondary: 'View Plans' },
    features: { title: 'Everything you need', subtitle: 'Complete infrastructure for your projects', uptime: '99.9% Uptime', uptimeDesc: 'Servers monitored 24/7 with automatic redundancy', deploy: 'Instant Deploy', deployDesc: 'Push your code and see it running in seconds', languages: 'Multi-language', languagesDesc: 'Support for Node.js, Python, Go, and more', security: 'Security', securityDesc: 'Free SSL, DDoS protection and automatic backups', files: 'File Editor', filesDesc: 'Edit your files directly from the panel', api: 'Complete API', apiDesc: 'RESTful API for automation and integrations' },
    plans: { title: 'Plans', subtitle: 'Choose the ideal plan for your project', free: 'Free', basic: 'Basic', standard: 'Standard', pro: 'Pro', advanced: 'Advanced', month: '/mo', current: 'Current Plan', select: 'Select', popular: 'Popular', ram: 'RAM', cpu: 'vCPU', storage: 'Storage', apps: 'Applications' },
    auth: { login: 'Login', register: 'Sign Up', email: 'Email', password: 'Password', confirmPassword: 'Confirm Password', name: 'Name', forgotPassword: 'Forgot password?', noAccount: "Don't have an account?", hasAccount: 'Already have an account?', orContinue: 'Or continue with' },
    dashboard: { myApps: 'My Applications', newApp: 'New Application', settings: 'Settings', billing: 'Billing', profile: 'Profile', logout: 'Logout', status: 'Status', online: 'Online', offline: 'Offline', starting: 'Starting', ram: 'RAM', cpu: 'CPU', upload: 'Upload', files: 'Files', console: 'Console', start: 'Start', stop: 'Stop', restart: 'Restart', delete: 'Delete', deploy: 'Deploy' },
    support: { title: 'Support', subtitle: "We're here to help", discord: 'Discord', discordDesc: 'Join our Discord server', docs: 'Documentation', docsDesc: 'Check our complete documentation', email: 'Email', emailDesc: 'Send an email to our team', faq: 'FAQ', faqTitle: 'Frequently Asked Questions' },
    about: { title: 'About Us', subtitle: 'Get to know Hosta', mission: 'Our Mission', missionText: 'Democratize access to quality hosting for developers of all levels.' },
    legal: { title: 'Legal Information', terms: 'Terms of Service', privacy: 'Privacy Policy', cookies: 'Cookie Policy' },
    footer: { description: 'Professional hosting platform for bots and websites.', product: 'Product', company: 'Company', legal: 'Legal', rights: 'All rights reserved.' },
  },
  es: {
    nav: { home: 'Inicio', plans: 'Planes', support: 'Soporte', about: 'Acerca', login: 'Iniciar Sesión', register: 'Registrarse', dashboard: 'Dashboard' },
    hero: { title: 'Hospeda tus bots y sitios con', highlight: 'simplicidad', subtitle: 'Plataforma de hospedaje profesional para Discord Bots, Sitios Web y Aplicaciones. Infraestructura confiable que nunca duerme.', cta: 'Empezar Gratis', ctaSecondary: 'Ver Planes' },
    features: { title: 'Todo lo que necesitas', subtitle: 'Infraestructura completa para tus proyectos', uptime: '99.9% Uptime', uptimeDesc: 'Servidores monitoreados 24/7 con redundancia automática', deploy: 'Deploy Instantáneo', deployDesc: 'Sube tu código y vélo corriendo en segundos', languages: 'Multi-lenguaje', languagesDesc: 'Soporte para Node.js, Python, Go y más', security: 'Seguridad', securityDesc: 'SSL gratis, protección DDoS y backups automáticos', files: 'Editor de Archivos', filesDesc: 'Edita tus archivos directamente desde el panel', api: 'API Completa', apiDesc: 'API RESTful para automatización e integraciones' },
    plans: { title: 'Planes', subtitle: 'Elige el plan ideal para tu proyecto', free: 'Free', basic: 'Basic', standard: 'Standard', pro: 'Pro', advanced: 'Advanced', month: '/mes', current: 'Plan Actual', select: 'Seleccionar', popular: 'Popular', ram: 'RAM', cpu: 'vCPU', storage: 'Almacenamiento', apps: 'Aplicaciones' },
    auth: { login: 'Iniciar Sesión', register: 'Registrarse', email: 'Email', password: 'Contraseña', confirmPassword: 'Confirmar Contraseña', name: 'Nombre', forgotPassword: '¿Olvidaste tu contraseña?', noAccount: '¿No tienes cuenta?', hasAccount: '¿Ya tienes cuenta?', orContinue: 'O continúa con' },
    dashboard: { myApps: 'Mis Aplicaciones', newApp: 'Nueva Aplicación', settings: 'Configuración', billing: 'Facturación', profile: 'Perfil', logout: 'Cerrar Sesión', status: 'Estado', online: 'Online', offline: 'Offline', starting: 'Iniciando', ram: 'RAM', cpu: 'CPU', upload: 'Subir', files: 'Archivos', console: 'Consola', start: 'Iniciar', stop: 'Detener', restart: 'Reiniciar', delete: 'Eliminar', deploy: 'Deploy' },
    support: { title: 'Soporte', subtitle: 'Estamos aquí para ayudar', discord: 'Discord', discordDesc: 'Únete a nuestro servidor Discord', docs: 'Documentación', docsDesc: 'Consulta nuestra documentación completa', email: 'Email', emailDesc: 'Envía un email a nuestro equipo', faq: 'FAQ', faqTitle: 'Preguntas Frecuentes' },
    about: { title: 'Sobre Nosotros', subtitle: 'Conoce a Hosta', mission: 'Nuestra Misión', missionText: 'Democratizar el acceso a hospedaje de calidad para desarrolladores de todos los niveles.' },
    legal: { title: 'Información Legal', terms: 'Términos de Servicio', privacy: 'Política de Privacidad', cookies: 'Política de Cookies' },
    footer: { description: 'Plataforma de hospedaje profesional para bots y sitios web.', product: 'Producto', company: 'Empresa', legal: 'Legal', rights: 'Todos los derechos reservados.' },
  },
} as const;

type Translations = typeof translations['pt'];
type TranslationsGeneric = { [K in keyof Translations]: { [P in keyof Translations[K]]: string } };

interface I18nContextType {
  locale: Locale;
  setLocale: (locale: Locale) => void;
  t: TranslationsGeneric;
}

const I18nContext = createContext<I18nContextType>({
  locale: 'pt',
  setLocale: () => {},
  t: translations.pt,
});

export const I18nProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [locale, setLocaleState] = useState<Locale>(() => {
    const saved = localStorage.getItem('hosta-locale');
    return (saved as Locale) || 'pt';
  });

  const setLocale = useCallback((l: Locale) => {
    setLocaleState(l);
    localStorage.setItem('hosta-locale', l);
  }, []);

  return (
    <I18nContext.Provider value={{ locale, setLocale, t: translations[locale] as unknown as TranslationsGeneric }}>
      {children}
    </I18nContext.Provider>
  );
};

export const useI18n = () => useContext(I18nContext);
