// API client for Pterodactyl panel integration
const API_BASE_URL = (import.meta.env.VITE_API_URL as string) || 'http://localhost:5000/api';

export interface PanelInstance {
  id: string;
  url: string;
  name: string;
  status: 'online' | 'offline';
  lastChecked: Date;
  stats?: {
    servers: number;
    nodes: number;
    users: number;
  };
}

export interface Server {
  uuid: string;
  name: string;
  suspended: boolean;
  status?: string;
  limits?: {
    memory: number;
    disk: number;
    cpu: number;
  };
}

export interface ServerResources {
  memory_bytes: number;
  memory_limit_bytes: number;
  cpu_absolute: number;
  disk_bytes: number;
  disk_limit_bytes: number;
  network_rx_bytes: number;
  network_tx_bytes: number;
  uptime: number;
  is_suspended: boolean;
}

class PterodactylService {
  /**
   * Add a new Pterodactyl panel
   */
  async addPanel(url: string, name?: string): Promise<PanelInstance> {
    const response = await fetch(`${API_BASE_URL}/pterodactyl/panels/add`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url, name }),
    });
    const data = await response.json();
    if (!data.success) throw new Error(data.error);
    return data.panel;
  }

  /**
   * Get all panels
   */
  async getPanels(): Promise<PanelInstance[]> {
    const response = await fetch(`${API_BASE_URL}/pterodactyl/panels`);
    const data = await response.json();
    if (!data.success) throw new Error(data.error);
    return data.panels;
  }

  /**
   * Check panel status
   */
  async checkPanelStatus(instanceId: string): Promise<{
    status: 'online' | 'offline';
    panel: PanelInstance;
  }> {
    const response = await fetch(`${API_BASE_URL}/pterodactyl/panels/${instanceId}/status`);
    const data = await response.json();
    if (!data.success) throw new Error(data.error);
    return data;
  }

  /**
   * Get servers from a panel
   */
  async getServers(instanceId: string): Promise<Server[]> {
    const response = await fetch(`${API_BASE_URL}/pterodactyl/panels/${instanceId}/servers`);
    const data = await response.json();
    if (!data.success) throw new Error(data.error);
    return data.servers;
  }

  /**
   * Get server details
   */
  async getServerDetails(instanceId: string, serverId: string): Promise<Server> {
    const response = await fetch(
      `${API_BASE_URL}/pterodactyl/panels/${instanceId}/servers/${serverId}`
    );
    const data = await response.json();
    if (!data.success) throw new Error(data.error);
    return data.server;
  }

  /**
   * Get server resources
   */
  async getServerResources(instanceId: string, serverId: string): Promise<ServerResources> {
    const response = await fetch(
      `${API_BASE_URL}/pterodactyl/panels/${instanceId}/servers/${serverId}/resources`
    );
    const data = await response.json();
    if (!data.success) throw new Error(data.error);
    return data.resources;
  }

  /**
   * Delete a panel
   */
  async deletePanel(instanceId: string): Promise<void> {
    const response = await fetch(`${API_BASE_URL}/pterodactyl/panels/${instanceId}`, {
      method: 'DELETE',
    });
    const data = await response.json();
    if (!data.success) throw new Error(data.error);
  }
}

export const pterodactylService = new PterodactylService();
