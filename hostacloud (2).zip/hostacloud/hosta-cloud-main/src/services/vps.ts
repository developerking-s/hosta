// VPS provider service
const API_BASE_URL = (import.meta.env.VITE_API_URL as string) || 'http://localhost:5000/api';

export interface VPSProvider {
  id: string;
  name: string;
  url: string;
  country: string;
  description: string;
  specs: {
    cpu: string;
    memory: string;
    disk: string;
  };
  rating: number;
}

export interface ServerMonitoring {
  id: string;
  name: string;
  ip: string;
  provider: string;
  status: 'online' | 'offline';
  cpu: { used: number; total: number };
  memory: { used: number; total: number };
  disk: { used: number; total: number };
  uptime: string;
}

class VPSService {
  /**
   * Get all VPS providers
   */
  async getProviders(): Promise<VPSProvider[]> {
    const response = await fetch(`${API_BASE_URL}/vps/providers`);
    const data = await response.json();
    if (!data.success) throw new Error(data.error);
    return data.providers;
  }

  /**
   * Get GratisVPS details
   */
  async getGratisVPS() {
    const response = await fetch(`${API_BASE_URL}/vps/providers/gratisvps`);
    const data = await response.json();
    if (!data.success) throw new Error(data.error);
    return data;
  }

  /**
   * Get VPSFree details
   */
  async getVPSFree() {
    const response = await fetch(`${API_BASE_URL}/vps/providers/vpsfree`);
    const data = await response.json();
    if (!data.success) throw new Error(data.error);
    return data;
  }

  /**
   * Get monitoring data
   */
  async getMonitoringData(): Promise<ServerMonitoring[]> {
    const response = await fetch(`${API_BASE_URL}/vps/monitoring/example`);
    const data = await response.json();
    if (!data.success) throw new Error(data.error);
    return data.data.servers;
  }
}

export const vpsService = new VPSService();
