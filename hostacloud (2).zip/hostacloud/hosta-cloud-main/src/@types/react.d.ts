declare module 'react' {
  type SetStateAction<S> = S | ((prevState: S) => S);
  type Dispatch<A> = (action: A) => void;

  export function useState<T>(initialState: T | (() => T)): [T, Dispatch<SetStateAction<T>>];
  export function useState<T = undefined>(): [T | undefined, Dispatch<SetStateAction<T | undefined>>];

  export const useEffect: any;
  export const useCallback: any;
  export const useMemo: any;
  export const useRef: any;
  export const useContext: any;
  export const createContext: any;
  export const ReactNode: any;

  export interface FC<P = {}> {
    (props: P & { children?: ReactNode }): ReactElement<any, any> | null;
  }

  export interface ReactElement<P = any, T extends string | any = any> {}
}

declare module 'react/jsx-runtime' {
  export const jsx: any;
  export const jsxs: any;
}
