declare module '@supabase/supabase-js' {
  export interface SupabaseClient {
    auth: any;
    from(table: string): any;
  }

  export function createClient<T = any>(url: string, key: string, options?: any): SupabaseClient;
  export interface Database {}
}
