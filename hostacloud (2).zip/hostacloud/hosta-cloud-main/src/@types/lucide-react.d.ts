declare module 'lucide-react' {
  export const Loader2: any;
  export const ExternalLink: any;
  export const Plus: any;
  export const Trash2: any;
  export const RefreshCw: any;
  export const Server: any;
  export const Menu: any;
  export const X: any;
  export const Globe: any;
  export const ChevronDown: any;
  [key: string]: any;
}
