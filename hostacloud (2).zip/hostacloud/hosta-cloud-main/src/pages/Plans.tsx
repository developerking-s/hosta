import PageLayout from '@/components/PageLayout';
import PricingCard from '@/components/PricingCard';
import { useI18n } from '@/lib/i18n';
import { motion } from 'framer-motion';

const Plans = () => {
  const { t } = useI18n();

  const plans = [
    { name: t.plans.free, price: '0', ram: '512 MB', cpu: '0.5', storage: '1 GB', apps: '1', features: ['Deploy automático', 'SSL gratuito', 'Logs básicos', 'Comunidade Discord'] },
    { name: t.plans.basic, price: '9.90', ram: '1 GB', cpu: '1', storage: '5 GB', apps: '3', features: ['Deploy automático', 'SSL gratuito', 'Logs avançados', 'Domínio custom', 'Suporte email'] },
    { name: t.plans.standard, price: '24.90', ram: '2 GB', cpu: '2', storage: '10 GB', apps: '5', features: ['Tudo do Basic', 'Backup diário', 'Suporte prioritário', 'API access', 'Webhooks'], popular: true },
    { name: t.plans.pro, price: '49.90', ram: '4 GB', cpu: '4', storage: '25 GB', apps: '10', features: ['Tudo do Standard', 'Auto-scaling', 'API avançada', 'Múltiplas regiões', 'SLA 99.9%'] },
    { name: t.plans.advanced, price: '99.90', ram: '8 GB', cpu: '8', storage: '50 GB', apps: '25', features: ['Tudo do Pro', 'Servidor dedicado', 'SLA 99.99%', 'Suporte 24/7', 'IP dedicado'] },
  ];

  return (
    <PageLayout>
      <section className="py-24">
        <div className="container mx-auto px-4">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-16">
            <h1 className="text-4xl md:text-6xl font-bold font-display mb-4">{t.plans.title}</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">{t.plans.subtitle}</p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
            {plans.map((plan, i) => (
              <motion.div key={i} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }}>
                <PricingCard {...plan} />
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </PageLayout>
  );
};

export default Plans;
