import PageLayout from '@/components/PageLayout';
import { motion } from 'framer-motion';
import { CheckCircle, AlertTriangle, XCircle, Clock, Server, Database, Globe, Shield, Wifi, Zap } from 'lucide-react';

const services = [
  { name: 'Web Dashboard', icon: Globe, status: 'operational', uptime: '99.99%' },
  { name: 'API Gateway', icon: Zap, status: 'operational', uptime: '99.98%' },
  { name: 'Bot Hosting', icon: Server, status: 'operational', uptime: '99.95%' },
  { name: 'File Storage', icon: Database, status: 'operational', uptime: '99.97%' },
  { name: 'SSL Certificates', icon: Shield, status: 'operational', uptime: '100%' },
  { name: 'DNS Resolution', icon: Wifi, status: 'operational', uptime: '99.99%' },
];

const incidents = [
  { date: '2026-02-18', title: 'Scheduled Maintenance', desc: 'Routine database optimization completed. No downtime.', status: 'resolved' },
  { date: '2026-02-10', title: 'Brief API Latency', desc: 'Increased latency on API endpoints for ~5 minutes. Auto-resolved by load balancer.', status: 'resolved' },
  { date: '2026-01-28', title: 'Network Upgrade', desc: 'Upgraded backbone network. All services migrated with zero downtime.', status: 'resolved' },
];

const statusIcon = (s: string) => {
  if (s === 'operational') return <CheckCircle className="h-4 w-4 text-success" />;
  if (s === 'degraded') return <AlertTriangle className="h-4 w-4 text-warning" />;
  return <XCircle className="h-4 w-4 text-destructive" />;
};

const Status = () => (
  <PageLayout>
    <section className="py-20">
      <div className="container mx-auto px-4 max-w-3xl">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-success/10 border border-success/20 mb-6">
            <CheckCircle className="h-4 w-4 text-success" />
            <span className="text-sm font-medium text-success">All Systems Operational</span>
          </div>
          <h1 className="text-3xl md:text-5xl font-bold font-display mb-3">System Status</h1>
          <p className="text-muted-foreground">Real-time monitoring of Hosta infrastructure</p>
        </motion.div>

        {/* Overall uptime */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
          className="bg-card/50 border border-border/50 rounded-xl p-5 mb-6">
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm font-medium">Overall Uptime (30 days)</span>
            <span className="text-2xl font-bold font-display text-success">99.98%</span>
          </div>
          <div className="flex gap-0.5">
            {Array.from({ length: 30 }, (_, i) => (
              <div key={i} className={`flex-1 h-8 rounded-sm ${i === 12 ? 'bg-warning/60' : 'bg-success/60'} hover:opacity-80 transition-opacity`} title={`Day ${30 - i}`} />
            ))}
          </div>
          <div className="flex justify-between text-[10px] text-muted-foreground mt-1.5">
            <span>30 days ago</span><span>Today</span>
          </div>
        </motion.div>

        {/* Services */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
          className="bg-card/50 border border-border/50 rounded-xl overflow-hidden mb-6">
          <div className="px-5 py-3 border-b border-border/50">
            <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">Services</span>
          </div>
          <div className="divide-y divide-border/30">
            {services.map(s => (
              <div key={s.name} className="flex items-center justify-between px-5 py-3.5 hover:bg-secondary/10 transition-colors">
                <div className="flex items-center gap-3">
                  <s.icon className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm font-medium">{s.name}</span>
                </div>
                <div className="flex items-center gap-4">
                  <span className="text-xs font-mono text-muted-foreground">{s.uptime}</span>
                  <div className="flex items-center gap-1.5">
                    {statusIcon(s.status)}
                    <span className="text-xs capitalize text-success">Operational</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Incidents */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}
          className="bg-card/50 border border-border/50 rounded-xl overflow-hidden">
          <div className="px-5 py-3 border-b border-border/50">
            <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">Recent Incidents</span>
          </div>
          <div className="divide-y divide-border/30">
            {incidents.map((inc, i) => (
              <div key={i} className="px-5 py-4">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-medium">{inc.title}</span>
                  <div className="flex items-center gap-1.5">
                    <Clock className="h-3 w-3 text-muted-foreground" />
                    <span className="text-[11px] text-muted-foreground">{inc.date}</span>
                  </div>
                </div>
                <p className="text-xs text-muted-foreground">{inc.desc}</p>
                <span className="inline-flex items-center gap-1 mt-2 px-2 py-0.5 rounded-full bg-success/10 text-success text-[10px] font-medium">
                  <CheckCircle className="h-3 w-3" /> Resolved
                </span>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  </PageLayout>
);

export default Status;
