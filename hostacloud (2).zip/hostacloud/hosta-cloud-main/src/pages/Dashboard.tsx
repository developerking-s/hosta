import { useState, useEffect, useCallback, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '@/lib/auth';
import { useI18n } from '@/lib/i18n';
import { supabase } from '@/integrations/supabase/client';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from 'sonner';
import {
  Server, LayoutDashboard, Settings, CreditCard, User, LogOut, Plus, Play, Square,
  RotateCcw, Trash2, Terminal, Activity, Menu,
  FileCode, File, Folder, Save, Bot, Globe,
  Plug, HardDrive, Cpu, MemoryStick, Wifi, WifiOff,
  FolderPlus, FilePlus, Search, Zap, Shield, Bell,
  BarChart3, Clock, Eye, EyeOff, Key, Mail,
  RefreshCw, Database, TrendingUp, ArrowUpRight, 
  Home, Package, AlertTriangle, CheckCircle2, XCircle
} from 'lucide-react';

type App = {
  id: string; name: string; type: string; language: string; status: string;
  ram_usage: string | null; cpu_usage: string | null; env_vars: any;
  start_command: string | null; created_at: string;
};
type AppFile = {
  id: string; app_id: string; path: string; name: string;
  content: string | null; is_folder: boolean; size_bytes: number | null;
};
type AppLog = { id: string; level: string; message: string; created_at: string; };

// ─── Metrics Hook ───
const useRealtimeMetrics = () => {
  const [metrics, setMetrics] = useState({
    ram: Math.random() * 40 + 10, cpu: Math.random() * 30 + 5,
    disk: Math.random() * 25 + 8, network: Math.random() * 15 + 2,
    requests: Math.floor(Math.random() * 1000), uptime: 99.97,
  });
  useEffect(() => {
    const interval = setInterval(() => {
      setMetrics(prev => ({
        ram: Math.max(5, Math.min(95, prev.ram + (Math.random() - 0.48) * 4)),
        cpu: Math.max(2, Math.min(90, prev.cpu + (Math.random() - 0.45) * 6)),
        disk: Math.max(5, Math.min(80, prev.disk + (Math.random() - 0.5) * 0.5)),
        network: Math.max(1, Math.min(60, prev.network + (Math.random() - 0.5) * 3)),
        requests: prev.requests + Math.floor(Math.random() * 20),
        uptime: 99.97,
      }));
    }, 2000);
    return () => clearInterval(interval);
  }, []);
  return metrics;
};

const useMetricHistory = (value: number, length = 30) => {
  const [history, setHistory] = useState<number[]>(() => Array.from({ length }, () => Math.random() * 50 + 10));
  useEffect(() => { setHistory(prev => [...prev.slice(1), value]); }, [value]);
  return history;
};

const Sparkline = ({ data, color, height = 40 }: { data: number[]; color: string; height?: number }) => {
  const max = Math.max(...data, 1);
  const min = Math.min(...data, 0);
  const range = max - min || 1;
  const w = 100;
  const points = data.map((v, i) => `${(i / (data.length - 1)) * w},${height - ((v - min) / range) * (height - 4)}`).join(' ');
  return (
    <svg viewBox={`0 0 ${w} ${height}`} className="w-full" style={{ height }} preserveAspectRatio="none">
      <defs>
        <linearGradient id={`grad-${color.replace('#','')}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.3" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      <polygon points={`0,${height} ${points} ${w},${height}`} fill={`url(#grad-${color.replace('#','')})`} />
      <polyline points={points} fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
};

// ─── Overview Page ───
const OverviewPage = ({ apps, metrics }: { apps: App[]; metrics: any }) => {
  const onlineCount = apps.filter(a => a.status === 'online').length;
  const ramH = useMetricHistory(metrics.ram);
  const cpuH = useMetricHistory(metrics.cpu);

  return (
    <div className="p-6 space-y-6 overflow-y-auto h-full">
      <div>
        <h1 className="text-xl font-bold font-display mb-1">Dashboard</h1>
        <p className="text-xs text-muted-foreground">Visão geral do seu ambiente</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {[
          { label: 'Total Servers', value: apps.length, icon: Server, accent: 'text-primary', sub: `${onlineCount} online` },
          { label: 'Uptime', value: '99.97%', icon: CheckCircle2, accent: 'text-success', sub: '30 dias' },
          { label: 'Requests', value: metrics.requests.toLocaleString(), icon: TrendingUp, accent: 'text-blue-400', sub: '/hora' },
          { label: 'Alerts', value: '0', icon: AlertTriangle, accent: 'text-success', sub: 'Tudo limpo' },
        ].map((s, i) => (
          <div key={i} className="bg-card border border-border rounded-xl p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] text-muted-foreground uppercase tracking-wider font-mono">{s.label}</span>
              <s.icon className={`h-4 w-4 ${s.accent}`} />
            </div>
            <span className="text-2xl font-bold font-display block">{s.value}</span>
            <span className="text-[10px] text-muted-foreground font-mono">{s.sub}</span>
          </div>
        ))}
      </div>

      {/* Resource charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {[
          { label: 'Memory Usage', value: metrics.ram, history: ramH, color: '#3b82f6', max: '512 MB' },
          { label: 'CPU Usage', value: metrics.cpu, history: cpuH, color: '#8b5cf6', max: '100%' },
        ].map((r, i) => (
          <div key={i} className="bg-card border border-border rounded-xl p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-medium">{r.label}</span>
              <div className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-success animate-pulse" />
                <span className="text-xs font-mono font-bold" style={{ color: r.color }}>{r.value.toFixed(1)}%</span>
              </div>
            </div>
            <Sparkline data={r.history} color={r.color} height={60} />
            <div className="h-1.5 bg-secondary rounded-full overflow-hidden mt-2">
              <div className="h-full rounded-full transition-all duration-1000" style={{ width: `${r.value}%`, backgroundColor: r.color }} />
            </div>
          </div>
        ))}
      </div>

      {/* Servers list quick view */}
      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <div className="px-4 py-3 border-b border-border flex items-center justify-between">
          <span className="text-xs font-medium">Servers</span>
          <span className="text-[10px] font-mono text-muted-foreground">{apps.length} total</span>
        </div>
        {apps.length === 0 ? (
          <div className="p-8 text-center text-xs text-muted-foreground">Nenhum server ainda</div>
        ) : (
          <div className="divide-y divide-border/50">
            {apps.slice(0, 5).map(app => (
              <div key={app.id} className="flex items-center justify-between px-4 py-3 hover:bg-secondary/10 transition-colors">
                <div className="flex items-center gap-3">
                  <div className={`w-2 h-2 rounded-full ${app.status === 'online' ? 'bg-success animate-pulse' : app.status === 'error' ? 'bg-destructive' : 'bg-muted-foreground/40'}`} />
                  <div>
                    <span className="text-sm font-medium">{app.name}</span>
                    <span className="text-[10px] font-mono text-muted-foreground ml-2">{app.language} • {app.type}</span>
                  </div>
                </div>
                <span className={`text-[10px] font-medium capitalize ${app.status === 'online' ? 'text-success' : app.status === 'error' ? 'text-destructive' : 'text-muted-foreground'}`}>
                  {app.status}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

// ─── Monitor Page ───
const MonitorPage = ({ apps, metrics }: { apps: App[]; metrics: any }) => {
  const ramH = useMetricHistory(metrics.ram);
  const cpuH = useMetricHistory(metrics.cpu);
  const netH = useMetricHistory(metrics.network);
  const diskH = useMetricHistory(metrics.disk);

  return (
    <div className="p-6 space-y-6 overflow-y-auto h-full">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold font-display mb-1">Monitor</h1>
          <p className="text-xs text-muted-foreground">Métricas em tempo real — atualiza a cada 2s</p>
        </div>
        <div className="flex items-center gap-1.5 px-2 py-1 rounded-full bg-success/10 border border-success/20">
          <span className="w-1.5 h-1.5 rounded-full bg-success animate-pulse" />
          <span className="text-[10px] font-mono text-success font-medium">LIVE</span>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {[
          { label: 'Memory', value: metrics.ram, history: ramH, color: '#3b82f6', unit: '%' },
          { label: 'CPU', value: metrics.cpu, history: cpuH, color: '#8b5cf6', unit: '%' },
          { label: 'Network', value: metrics.network, history: netH, color: '#10b981', unit: ' Mb/s' },
          { label: 'Disk', value: metrics.disk, history: diskH, color: '#f59e0b', unit: '%' },
        ].map((r, i) => (
          <div key={i} className="bg-card border border-border rounded-xl p-4">
            <div className="flex items-center justify-between mb-1">
              <span className="text-[10px] text-muted-foreground uppercase tracking-wider font-mono">{r.label}</span>
              <span className="text-xs font-mono font-bold" style={{ color: r.color }}>{r.value.toFixed(1)}{r.unit}</span>
            </div>
            <Sparkline data={r.history} color={r.color} height={50} />
            <div className="h-1 bg-secondary rounded-full overflow-hidden mt-2">
              <div className="h-full rounded-full transition-all duration-1000" style={{ width: `${Math.min(r.value, 100)}%`, backgroundColor: r.color }} />
            </div>
          </div>
        ))}
      </div>

      {/* Server status table */}
      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <div className="px-4 py-3 border-b border-border">
          <span className="text-xs font-medium">Server Status</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border/50 text-[10px] font-mono text-muted-foreground uppercase tracking-wider">
                <th className="text-left px-4 py-2">Server</th>
                <th className="text-left px-4 py-2">Status</th>
                <th className="text-left px-4 py-2">RAM</th>
                <th className="text-left px-4 py-2">CPU</th>
                <th className="text-left px-4 py-2">Uptime</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/30">
              {apps.length === 0 && (
                <tr><td colSpan={5} className="px-4 py-8 text-center text-xs text-muted-foreground">Sem servers</td></tr>
              )}
              {apps.map(app => (
                <tr key={app.id} className="hover:bg-secondary/10 transition-colors">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <div className={`w-2 h-2 rounded-full ${app.status === 'online' ? 'bg-success animate-pulse' : 'bg-muted-foreground/40'}`} />
                      <span className="text-sm font-medium">{app.name}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`text-xs font-medium capitalize ${app.status === 'online' ? 'text-success' : app.status === 'error' ? 'text-destructive' : 'text-muted-foreground'}`}>{app.status}</span>
                  </td>
                  <td className="px-4 py-3 text-xs font-mono text-muted-foreground">{(Math.random() * 200 + 50).toFixed(0)} MB</td>
                  <td className="px-4 py-3 text-xs font-mono text-muted-foreground">{(Math.random() * 30 + 2).toFixed(1)}%</td>
                  <td className="px-4 py-3 text-xs font-mono text-success">99.9%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

// ─── Billing Page ───
const BillingPage = ({ profile }: { profile: any }) => {
  const currentPlan = profile?.plan || 'free';
  const plans = [
    { name: 'Free', price: '0', ram: '512 MB', apps: 1, highlight: false },
    { name: 'Basic', price: '9.90', ram: '1 GB', apps: 3, highlight: false },
    { name: 'Standard', price: '24.90', ram: '2 GB', apps: 5, highlight: true },
    { name: 'Pro', price: '49.90', ram: '4 GB', apps: 10, highlight: false },
    { name: 'Advanced', price: '99.90', ram: '8 GB', apps: 25, highlight: false },
  ];

  return (
    <div className="p-6 space-y-6 overflow-y-auto h-full">
      <div>
        <h1 className="text-xl font-bold font-display mb-1">Billing</h1>
        <p className="text-xs text-muted-foreground">Gerencie seu plano e pagamento</p>
      </div>

      <div className="bg-card border border-primary/30 rounded-xl p-6">
        <div className="flex items-center justify-between">
          <div>
            <span className="text-xs text-muted-foreground">Plano atual</span>
            <div className="flex items-center gap-2 mt-1">
              <Zap className="h-5 w-5 text-primary" />
              <span className="text-xl font-bold font-display capitalize">{currentPlan}</span>
            </div>
          </div>
          <div className="text-right">
            <span className="text-xs text-muted-foreground">Período</span>
            <div className="text-sm font-mono mt-1">Fev 2026</div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
        {plans.map(plan => (
          <div key={plan.name} className={`bg-card border rounded-xl p-4 transition-all hover:border-primary/30 ${plan.name.toLowerCase() === currentPlan ? 'border-primary/50 ring-1 ring-primary/20' : 'border-border'}`}>
            <h4 className="font-bold font-display text-sm">{plan.name}</h4>
            <div className="mt-1 mb-3">
              <span className="text-lg font-bold">{plan.price === '0' ? 'Free' : `R$${plan.price}`}</span>
              {plan.price !== '0' && <span className="text-[10px] text-muted-foreground">/mês</span>}
            </div>
            <div className="text-[10px] text-muted-foreground space-y-1">
              <div>RAM: <span className="text-foreground font-mono">{plan.ram}</span></div>
              <div>Apps: <span className="text-foreground font-mono">{plan.apps}</span></div>
            </div>
            <button className={`w-full mt-3 py-1.5 rounded-lg text-[11px] font-medium transition-all ${
              plan.name.toLowerCase() === currentPlan ? 'bg-primary/10 text-primary border border-primary/20' : 'bg-secondary text-foreground hover:bg-secondary/80 border border-border'
            }`}>
              {plan.name.toLowerCase() === currentPlan ? 'Atual' : 'Upgrade'}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

// ─── Settings Page ───
const SettingsPage = ({ profile, user }: { profile: any; user: any }) => {
  const [displayName, setDisplayName] = useState(profile?.display_name || '');
  const [saving, setSaving] = useState(false);
  const [notifs, setNotifs] = useState({ status: true, resources: true, billing: false });

  const saveProfile = async () => {
    if (!user || !displayName.trim()) return;
    setSaving(true);
    const { error } = await supabase.from('profiles').update({ display_name: displayName }).eq('user_id', user.id);
    setSaving(false);
    if (error) toast.error(error.message);
    else toast.success('Perfil atualizado!');
  };

  return (
    <div className="p-6 space-y-6 overflow-y-auto h-full max-w-3xl">
      <div>
        <h1 className="text-xl font-bold font-display mb-1">Settings</h1>
        <p className="text-xs text-muted-foreground">Configurações da conta</p>
      </div>

      {/* Profile */}
      <div className="bg-card border border-border rounded-xl p-5">
        <h3 className="text-sm font-semibold font-display mb-4 flex items-center gap-2"><User className="h-4 w-4 text-primary" /> Perfil</h3>
        <div className="space-y-3">
          <div>
            <label className="text-[11px] text-muted-foreground block mb-1">Nome</label>
            <input className="w-full px-3 py-2 rounded-lg bg-input border border-border text-sm focus:outline-none focus:ring-1 focus:ring-primary/50" value={displayName} onChange={e => setDisplayName(e.target.value)} />
          </div>
          <div>
            <label className="text-[11px] text-muted-foreground block mb-1">Email</label>
            <input className="w-full px-3 py-2 rounded-lg bg-input border border-border text-sm text-muted-foreground" value={user?.email || ''} readOnly />
          </div>
          <button onClick={saveProfile} disabled={saving} className="px-4 py-2 rounded-lg gradient-primary text-primary-foreground text-xs font-medium hover:opacity-90 transition-all disabled:opacity-50">
            {saving ? 'Salvando...' : 'Salvar'}
          </button>
        </div>
      </div>

      {/* Hosting Engine */}
      <div className="bg-card border border-primary/20 rounded-xl p-5">
        <h3 className="text-sm font-semibold font-display mb-1 flex items-center gap-2">
          <Database className="h-4 w-4 text-primary" /> Hosting Engine
        </h3>
        <p className="text-[11px] text-muted-foreground mb-3">Hospedagem gratuita integrada — sem necessidade de chave</p>
        <div className="bg-background rounded-lg p-4 border border-border/50">
          <div className="flex items-center gap-2 mb-1">
            <span className="w-2 h-2 rounded-full bg-success" />
            <span className="text-xs font-medium text-success">Conectado</span>
          </div>
          <p className="text-[11px] text-muted-foreground">
            Seus servers são hospedados automaticamente. Plano gratuito com execução 24/7.
          </p>
        </div>
      </div>

      {/* Notifications */}
      <div className="bg-card border border-border rounded-xl p-5">
        <h3 className="text-sm font-semibold font-display mb-4 flex items-center gap-2"><Bell className="h-4 w-4 text-primary" /> Notificações</h3>
        {[
          { key: 'status' as const, label: 'Status changes', desc: 'Quando um server sobe/cai' },
          { key: 'resources' as const, label: 'Resource alerts', desc: 'Quando RAM/CPU > 80%' },
          { key: 'billing' as const, label: 'Billing', desc: 'Lembretes de pagamento' },
        ].map(n => (
          <div key={n.key} className="flex items-center justify-between py-2.5 border-b border-border/30 last:border-0">
            <div>
              <span className="text-sm">{n.label}</span>
              <span className="text-[10px] text-muted-foreground block">{n.desc}</span>
            </div>
            <button onClick={() => setNotifs(p => ({ ...p, [n.key]: !p[n.key] }))} className={`w-9 h-5 rounded-full transition-colors relative ${notifs[n.key] ? 'bg-primary' : 'bg-secondary'}`}>
              <div className={`absolute top-0.5 w-4 h-4 rounded-full bg-white transition-all ${notifs[n.key] ? 'left-[18px]' : 'left-0.5'}`} />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

// ─── Main Dashboard ───
const Dashboard = () => {
  const { t } = useI18n();
  const { user, signOut, profile, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const logsEndRef = useRef<HTMLDivElement>(null);

  const [apps, setApps] = useState<App[]>([]);
  const [selectedApp, setSelectedApp] = useState<App | null>(null);
  const [activeTab, setActiveTab] = useState<'overview' | 'files' | 'console' | 'settings'>('overview');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [files, setFiles] = useState<AppFile[]>([]);
  const [logs, setLogs] = useState<AppLog[]>([]);
  const [selectedFile, setSelectedFile] = useState<AppFile | null>(null);
  const [fileContent, setFileContent] = useState('');
  const [showNewAppModal, setShowNewAppModal] = useState(false);
  const [newApp, setNewApp] = useState({ name: '', type: 'bot', language: 'node' });
  const [envKey, setEnvKey] = useState('');
  const [envValue, setEnvValue] = useState('');
  const [activePage, setActivePage] = useState('overview');
  const [fileDirty, setFileDirty] = useState(false);
  const [commandInput, setCommandInput] = useState('');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const metrics = useRealtimeMetrics();

  useEffect(() => { if (!authLoading && !user) navigate('/login'); }, [user, authLoading, navigate]);

  const fetchApps = useCallback(async () => {
    if (!user) return;
    const { data } = await supabase.from('apps').select('*').eq('user_id', user.id).order('created_at', { ascending: false });
    if (data) { setApps(data); if (!selectedApp && data.length > 0) setSelectedApp(data[0]); }
  }, [user, selectedApp]);

  useEffect(() => { fetchApps(); }, [fetchApps]);

  useEffect(() => {
    if (!selectedApp || !user) return;
    supabase.from('app_files').select('*').eq('app_id', selectedApp.id).order('is_folder', { ascending: false }).order('name')
      .then(({ data }) => { if (data) setFiles(data); });
  }, [selectedApp, user]);

  useEffect(() => {
    if (!selectedApp || !user) return;
    supabase.from('app_logs').select('*').eq('app_id', selectedApp.id).order('created_at', { ascending: false }).limit(100)
      .then(({ data }) => { if (data) setLogs(data); });
    const channel = supabase.channel(`logs-${selectedApp.id}`)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'app_logs', filter: `app_id=eq.${selectedApp.id}` },
        (payload) => { setLogs(prev => [payload.new as AppLog, ...prev].slice(0, 200)); })
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [selectedApp, user]);

  const createApp = async () => {
    if (!user || !newApp.name.trim()) return;
    const { data, error } = await supabase.from('apps').insert({ user_id: user.id, name: newApp.name, type: newApp.type, language: newApp.language }).select().single();
    if (error) { toast.error(error.message); return; }
    if (data) {
      await supabase.from('app_files').insert([
        { app_id: data.id, user_id: user.id, path: '/', name: 'index.js', content: '// Welcome to Hosta!\nconsole.log("Hello from Hosta!");', is_folder: false },
        { app_id: data.id, user_id: user.id, path: '/', name: 'package.json', content: `{\n  "name": "${newApp.name}",\n  "version": "1.0.0",\n  "main": "index.js"\n}`, is_folder: false },
      ]);
      await supabase.from('app_logs').insert({ app_id: data.id, user_id: user.id, level: 'info', message: `Application "${newApp.name}" created.` });
      setApps(prev => [data, ...prev]); setSelectedApp(data); setShowNewAppModal(false);
      setNewApp({ name: '', type: 'bot', language: 'node' }); setActivePage('servers'); toast.success('Server criado!');
    }
  };

  const deleteApp = async () => {
    if (!selectedApp || !confirm('Tem certeza? Esta ação é irreversível.')) return;
    const { error } = await supabase.from('apps').delete().eq('id', selectedApp.id);
    if (error) { toast.error(error.message); return; }
    setApps(prev => prev.filter(a => a.id !== selectedApp.id)); setSelectedApp(null); toast.success('Server excluído');
  };

  const toggleAppStatus = async (status: string) => {
    if (!selectedApp) return;
    const { error } = await supabase.from('apps').update({ status }).eq('id', selectedApp.id);
    if (error) { toast.error(error.message); return; }
    const updated = { ...selectedApp, status };
    setSelectedApp(updated);
    setApps(prev => prev.map(a => a.id === selectedApp.id ? updated : a));
    await supabase.from('app_logs').insert({ app_id: selectedApp.id, user_id: user!.id, level: 'info', message: `Server ${status === 'online' ? 'started' : 'stopped'}.` });
    toast.success(`Server ${status === 'online' ? 'iniciado' : 'parado'}!`);
  };

  const saveFile = async () => {
    if (!selectedFile) return;
    const { error } = await supabase.from('app_files').update({ content: fileContent }).eq('id', selectedFile.id);
    if (error) { toast.error(error.message); return; }
    setFileDirty(false); toast.success('Arquivo salvo!');
  };

  const addEnvVar = async () => {
    if (!selectedApp || !envKey.trim()) return;
    const currentVars = (selectedApp.env_vars as Record<string, string>) || {};
    const updated = { ...currentVars, [envKey]: envValue };
    const { error } = await supabase.from('apps').update({ env_vars: updated }).eq('id', selectedApp.id);
    if (error) { toast.error(error.message); return; }
    setSelectedApp(prev => prev ? { ...prev, env_vars: updated } : null);
    setEnvKey(''); setEnvValue(''); toast.success('Variável adicionada');
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 's') { e.preventDefault(); saveFile(); }
    if (e.key === 'Tab') {
      e.preventDefault(); const ta = e.currentTarget; const start = ta.selectionStart; const end = ta.selectionEnd;
      setFileContent(fileContent.substring(0, start) + '  ' + fileContent.substring(end));
      setTimeout(() => { ta.selectionStart = ta.selectionEnd = start + 2; }, 0);
    }
  };

  const statusBadge = (s: string) => {
    const map: Record<string, { bg: string; text: string; dot: string; label: string }> = {
      online: { bg: 'bg-success/10', text: 'text-success', dot: 'bg-success', label: 'Online' },
      starting: { bg: 'bg-warning/10', text: 'text-warning', dot: 'bg-warning', label: 'Starting' },
      error: { bg: 'bg-destructive/10', text: 'text-destructive', dot: 'bg-destructive', label: 'Error' },
      offline: { bg: 'bg-muted', text: 'text-muted-foreground', dot: 'bg-muted-foreground', label: 'Offline' },
    };
    const m = map[s] || map.offline;
    return (<span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-medium ${m.bg} ${m.text}`}><span className={`w-1.5 h-1.5 rounded-full ${m.dot} ${s === 'online' ? 'animate-pulse' : ''}`} />{m.label}</span>);
  };

  const logColor = (l: string) => l === 'error' ? 'text-red-400' : l === 'warn' ? 'text-yellow-400' : l === 'debug' ? 'text-muted-foreground' : 'text-emerald-400';
  const typeIcon = (tp: string) => tp === 'bot' ? Bot : tp === 'site' ? Globe : Plug;
  const langColor = (l: string) => l === 'node' ? 'text-emerald-400' : l === 'python' ? 'text-blue-400' : l === 'go' ? 'text-cyan-400' : 'text-orange-400';
  const lineNumbers = fileContent.split('\n').length;

  if (authLoading) return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <div className="flex flex-col items-center gap-3"><div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" /><span className="text-xs text-muted-foreground">Loading...</span></div>
    </div>
  );

  const sidebarItems = [
    { icon: Home, label: 'Overview', id: 'overview' },
    { icon: Server, label: 'Servers', id: 'servers' },
    { icon: Activity, label: 'Monitor', id: 'monitor' },
    { icon: CreditCard, label: 'Billing', id: 'billing' },
    { icon: Settings, label: 'Settings', id: 'settings-page' },
  ];

  const renderPage = () => {
    if (activePage === 'overview') return <OverviewPage apps={apps} metrics={metrics} />;
    if (activePage === 'monitor') return <MonitorPage apps={apps} metrics={metrics} />;
    if (activePage === 'billing') return <BillingPage profile={profile} />;
    if (activePage === 'settings-page') return <SettingsPage profile={profile} user={user} />;
    return renderServersPage();
  };

  const renderServersPage = () => (
    <div className="flex-1 flex min-h-0">
      {/* Server list sidebar */}
      <div className="w-56 border-r border-border overflow-y-auto shrink-0 bg-card/20 hidden md:flex flex-col">
        <div className="p-3 border-b border-border">
          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
            <input className="w-full pl-8 pr-3 py-1.5 rounded-md bg-input border border-border text-xs focus:outline-none focus:ring-1 focus:ring-primary/50 placeholder:text-muted-foreground/50" placeholder="Buscar..." />
          </div>
        </div>
        <div className="flex-1 p-1.5 space-y-0.5 overflow-y-auto">
          {apps.length === 0 && (
            <div className="p-6 text-center">
              <Server className="h-8 w-8 text-muted-foreground/20 mx-auto mb-2" />
              <p className="text-xs text-muted-foreground">Nenhum server</p>
              <button onClick={() => setShowNewAppModal(true)} className="mt-2 text-primary hover:underline text-xs">Criar primeiro</button>
            </div>
          )}
          {apps.map(app => {
            const Icon = typeIcon(app.type);
            return (
              <button key={app.id} onClick={() => { setSelectedApp(app); setSelectedFile(null); setActiveTab('overview'); }}
                className={`w-full text-left px-3 py-2.5 rounded-lg transition-all ${selectedApp?.id === app.id ? 'bg-primary/10 border border-primary/20' : 'hover:bg-secondary/30 border border-transparent'}`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 min-w-0">
                    <Icon className={`h-3.5 w-3.5 shrink-0 ${selectedApp?.id === app.id ? 'text-primary' : 'text-muted-foreground'}`} />
                    <div className="min-w-0">
                      <span className="text-xs font-medium truncate block">{app.name}</span>
                      <span className={`text-[10px] ${langColor(app.language)} font-mono`}>{app.language}</span>
                    </div>
                  </div>
                  <div className={`w-2 h-2 rounded-full shrink-0 ${app.status === 'online' ? 'bg-success animate-pulse' : app.status === 'error' ? 'bg-destructive' : 'bg-muted-foreground/40'}`} />
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* App detail */}
      {selectedApp ? (
        <div className="flex-1 flex flex-col min-w-0">
          {/* App header */}
          <div className="px-4 py-3 border-b border-border flex items-center justify-between gap-3 bg-card/10">
            <div className="flex items-center gap-3 min-w-0">
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="font-semibold font-display text-sm">{selectedApp.name}</h2>
                  {statusBadge(selectedApp.status)}
                </div>
                <span className="text-[11px] font-mono text-muted-foreground">{selectedApp.language} • {selectedApp.type}</span>
              </div>
            </div>
            <div className="flex items-center gap-1">
              <button onClick={() => toggleAppStatus('online')} className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-success/10 text-success text-xs font-medium hover:bg-success/20 transition-colors border border-success/20"><Play className="h-3 w-3" /> Start</button>
              <button onClick={() => toggleAppStatus('offline')} className="p-1.5 rounded-md bg-destructive/10 text-destructive hover:bg-destructive/20 transition-colors border border-destructive/20"><Square className="h-3 w-3" /></button>
              <button onClick={() => { toggleAppStatus('starting'); setTimeout(() => toggleAppStatus('online'), 2000); }} className="p-1.5 rounded-md bg-warning/10 text-warning hover:bg-warning/20 transition-colors border border-warning/20"><RotateCcw className="h-3 w-3" /></button>
            </div>
          </div>

          {/* Tabs */}
          <div className="px-4 border-b border-border flex gap-0 bg-card/5">
            {([
              { id: 'overview' as const, icon: Activity, label: 'Overview' },
              { id: 'files' as const, icon: FileCode, label: 'Files' },
              { id: 'console' as const, icon: Terminal, label: 'Console' },
              { id: 'settings' as const, icon: Settings, label: 'Settings' },
            ] as const).map(tab => (
              <button key={tab.id} onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-1.5 px-4 py-2.5 text-xs font-medium border-b-2 transition-all -mb-px ${activeTab === tab.id ? 'border-primary text-foreground' : 'border-transparent text-muted-foreground hover:text-foreground'}`}>
                <tab.icon className="h-3.5 w-3.5" />{tab.label}
              </button>
            ))}
          </div>

          <div className="flex-1 overflow-hidden">
            {activeTab === 'overview' && (
              <div className="p-4 md:p-6 overflow-y-auto h-full space-y-4">
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
                  {[
                    { label: 'Status', value: selectedApp.status, icon: selectedApp.status === 'online' ? Wifi : WifiOff, accent: selectedApp.status === 'online' ? 'text-success' : 'text-muted-foreground' },
                    { label: 'Memory', value: `${metrics.ram.toFixed(0)} MB`, icon: MemoryStick, accent: 'text-blue-400' },
                    { label: 'CPU', value: `${metrics.cpu.toFixed(1)}%`, icon: Cpu, accent: 'text-violet-400' },
                    { label: 'Files', value: String(files.length), icon: HardDrive, accent: 'text-amber-400' },
                  ].map((s, i) => (
                    <div key={i} className="bg-card border border-border rounded-xl p-4">
                      <div className="flex items-center justify-between mb-2"><span className="text-[11px] text-muted-foreground uppercase tracking-wider">{s.label}</span><s.icon className={`h-4 w-4 ${s.accent}`} /></div>
                      <span className="text-lg font-bold font-display capitalize">{s.value}</span>
                    </div>
                  ))}
                </div>

                {/* Logs preview */}
                <div className="bg-card border border-border rounded-xl overflow-hidden">
                  <div className="flex items-center justify-between px-4 py-3 border-b border-border">
                    <div className="flex items-center gap-2"><Terminal className="h-3.5 w-3.5 text-primary" /><span className="text-xs font-medium">Logs Recentes</span></div>
                    <button onClick={() => setActiveTab('console')} className="text-[10px] text-primary hover:underline">Ver Todos →</button>
                  </div>
                  <div className="p-3 font-mono text-[11px] space-y-0.5 max-h-48 overflow-y-auto bg-background/50">
                    {logs.length === 0 && <p className="text-muted-foreground py-2 text-center">Sem logs</p>}
                    {logs.slice(0, 8).map(log => (
                      <div key={log.id} className="flex gap-2 py-0.5 px-1">
                        <span className="text-muted-foreground/50 shrink-0">{new Date(log.created_at).toLocaleTimeString()}</span>
                        <span className={`shrink-0 uppercase w-10 ${logColor(log.level)}`}>{log.level}</span>
                        <span className="text-foreground/80 break-all">{log.message}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'files' && (
              <div className="flex h-full">
                <div className="w-52 border-r border-border flex flex-col shrink-0 bg-card/20">
                  <div className="flex items-center justify-between p-2 border-b border-border/50">
                    <span className="text-[10px] font-medium text-muted-foreground uppercase tracking-wider px-1">Explorer</span>
                    <div className="flex gap-0.5">
                      <button className="p-1 rounded hover:bg-secondary/50 text-muted-foreground"><FilePlus className="h-3.5 w-3.5" /></button>
                      <button className="p-1 rounded hover:bg-secondary/50 text-muted-foreground"><FolderPlus className="h-3.5 w-3.5" /></button>
                    </div>
                  </div>
                  <div className="flex-1 overflow-y-auto p-1">
                    {files.map(f => (
                      <button key={f.id} onClick={() => { setSelectedFile(f); setFileContent(f.content || ''); setFileDirty(false); }}
                        className={`flex items-center gap-2 w-full px-2 py-1.5 rounded-md text-left text-[12px] ${selectedFile?.id === f.id ? 'bg-primary/10 text-primary' : 'text-muted-foreground hover:bg-secondary/30'}`}>
                        {f.is_folder ? <Folder className="h-3.5 w-3.5 text-primary/60 shrink-0" /> : <File className="h-3.5 w-3.5 shrink-0 opacity-50" />}
                        <span className="font-mono truncate">{f.name}</span>
                      </button>
                    ))}
                    {files.length === 0 && <p className="text-[11px] text-muted-foreground text-center py-4">Sem arquivos</p>}
                  </div>
                </div>
                <div className="flex-1 flex flex-col min-w-0">
                  {selectedFile ? (
                    <>
                      <div className="flex items-center justify-between px-3 py-1.5 border-b border-border/50 bg-card/20">
                        <div className="flex items-center gap-1.5 text-[11px]">
                          <File className="h-3 w-3 text-muted-foreground" />
                          <span className="font-mono text-muted-foreground">{selectedFile.name}</span>
                          {fileDirty && <span className="w-1.5 h-1.5 rounded-full bg-primary" />}
                        </div>
                        <button onClick={saveFile} className="flex items-center gap-1 px-2 py-1 rounded-md gradient-primary text-primary-foreground text-[11px] font-medium hover:opacity-90"><Save className="h-3 w-3" />Save</button>
                      </div>
                      <div className="flex-1 flex overflow-hidden">
                        <div className="py-3 px-2 bg-card/30 border-r border-border/30 select-none shrink-0">
                          {Array.from({ length: lineNumbers }, (_, i) => (<div key={i} className="text-[11px] font-mono text-muted-foreground/30 leading-[1.65] text-right pr-1 min-w-[2ch]">{i + 1}</div>))}
                        </div>
                        <textarea value={fileContent} onChange={e => { setFileContent(e.target.value); setFileDirty(true); }} onKeyDown={handleKeyDown}
                          className="flex-1 py-3 px-3 bg-background/80 font-mono text-[12px] text-foreground resize-none focus:outline-none leading-[1.65] overflow-auto" spellCheck={false} />
                      </div>
                    </>
                  ) : (
                    <div className="flex-1 flex flex-col items-center justify-center text-muted-foreground/50 gap-2"><FileCode className="h-10 w-10" /><span className="text-xs">Selecione um arquivo</span></div>
                  )}
                </div>
              </div>
            )}

            {activeTab === 'console' && (
              <div className="flex flex-col h-full">
                <div className="flex items-center gap-2 px-4 py-2 border-b border-border/50 bg-card/20">
                  <div className="flex gap-1.5"><div className="w-2.5 h-2.5 rounded-full bg-destructive/50" /><div className="w-2.5 h-2.5 rounded-full bg-warning/50" /><div className="w-2.5 h-2.5 rounded-full bg-success/50" /></div>
                  <span className="text-[11px] font-mono text-muted-foreground ml-1">terminal — {selectedApp.name}</span>
                  <div className="flex-1" />{statusBadge(selectedApp.status)}
                </div>
                <div className="flex-1 bg-background/90 p-3 font-mono text-[11px] space-y-px overflow-y-auto">
                  {logs.length === 0 && <p className="text-muted-foreground/50 py-4 text-center">Aguardando output...</p>}
                  {[...logs].reverse().map(log => (
                    <div key={log.id} className="flex gap-2 py-px px-1">
                      <span className="text-muted-foreground/40 shrink-0">{new Date(log.created_at).toLocaleTimeString()}</span>
                      <span className={logColor(log.level)}>{log.message}</span>
                    </div>
                  ))}
                  <div ref={logsEndRef} />
                </div>
                <div className="border-t border-border/50 bg-card/20 px-3 py-2 flex items-center gap-2">
                  <span className="text-primary text-xs font-mono">$</span>
                  <input value={commandInput} onChange={e => setCommandInput(e.target.value)}
                    className="flex-1 bg-transparent text-xs font-mono text-foreground focus:outline-none placeholder:text-muted-foreground/30" placeholder="Digite um comando..."
                    onKeyDown={async e => {
                      if (e.key === 'Enter' && commandInput.trim() && selectedApp && user) {
                        await supabase.from('app_logs').insert({ app_id: selectedApp.id, user_id: user.id, level: 'info', message: `> ${commandInput}` });
                        setCommandInput('');
                      }
                    }} />
                </div>
              </div>
            )}

            {activeTab === 'settings' && (
              <div className="p-4 md:p-6 overflow-y-auto h-full space-y-4 max-w-2xl">
                <div className="bg-card border border-border rounded-xl p-5">
                  <h3 className="font-semibold font-display text-sm mb-1">Start Command</h3>
                  <p className="text-[11px] text-muted-foreground mb-3">Comando para iniciar sua aplicação</p>
                  <input className="w-full px-3 py-2 rounded-lg bg-input border border-border text-sm font-mono focus:outline-none focus:ring-1 focus:ring-primary/50" value={selectedApp.start_command || 'node index.js'} readOnly />
                </div>
                <div className="bg-card border border-border rounded-xl p-5">
                  <h3 className="font-semibold font-display text-sm mb-1">Environment Variables</h3>
                  <p className="text-[11px] text-muted-foreground mb-3">Configure suas variáveis de ambiente</p>
                  {selectedApp.env_vars && Object.entries(selectedApp.env_vars as Record<string, string>).map(([k]) => (
                    <div key={k} className="flex gap-2 mb-2">
                      <div className="flex-1 px-3 py-2 rounded-md bg-background border border-border/50 text-xs font-mono">{k}</div>
                      <div className="flex-1 px-3 py-2 rounded-md bg-background border border-border/50 text-xs font-mono text-muted-foreground">••••••</div>
                    </div>
                  ))}
                  <div className="flex gap-2 mt-3">
                    <input value={envKey} onChange={e => setEnvKey(e.target.value)} className="flex-1 px-3 py-2 rounded-md bg-input border border-border text-xs font-mono focus:outline-none focus:ring-1 focus:ring-primary/50" placeholder="KEY" />
                    <input value={envValue} onChange={e => setEnvValue(e.target.value)} className="flex-1 px-3 py-2 rounded-md bg-input border border-border text-xs font-mono focus:outline-none focus:ring-1 focus:ring-primary/50" placeholder="VALUE" />
                    <button onClick={addEnvVar} className="px-3 py-2 rounded-md gradient-primary text-primary-foreground text-xs font-medium hover:opacity-90">Add</button>
                  </div>
                </div>
                <div className="bg-card border border-destructive/20 rounded-xl p-5">
                  <h3 className="font-semibold font-display text-sm text-destructive mb-1">Danger Zone</h3>
                  <p className="text-[11px] text-muted-foreground mb-3">Ações irreversíveis</p>
                  <button onClick={deleteApp} className="flex items-center gap-2 px-4 py-2 rounded-lg bg-destructive/10 text-destructive text-xs font-medium hover:bg-destructive/20 border border-destructive/20"><Trash2 className="h-3.5 w-3.5" />Excluir Server</button>
                </div>
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="flex-1 flex flex-col items-center justify-center text-muted-foreground gap-4 p-8">
          <Server className="h-12 w-12 text-muted-foreground/20" />
          <div className="text-center">
            <p className="text-sm font-medium mb-1">Nenhum server selecionado</p>
            <p className="text-xs text-muted-foreground/60">Crie ou selecione um server</p>
          </div>
          <button onClick={() => setShowNewAppModal(true)} className="px-4 py-2 rounded-lg gradient-primary text-primary-foreground text-xs font-medium glow-sm hover:opacity-90">Criar Server</button>
        </div>
      )}
    </div>
  );

  return (
    <div className="min-h-screen flex bg-background text-foreground">
      {/* Sidebar */}
      <aside className={`${sidebarCollapsed ? 'w-14' : 'w-52'} bg-card border-r border-border flex flex-col transition-all duration-200 shrink-0 hidden md:flex`}>
        <div className="h-14 flex items-center gap-2.5 px-3 border-b border-border">
          <Link to="/" className="flex items-center gap-2.5">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg gradient-primary shrink-0"><Server className="h-4 w-4 text-primary-foreground" /></div>
            {!sidebarCollapsed && <span className="text-base font-bold font-display tracking-tight">Hosta</span>}
          </Link>
        </div>
        <nav className="flex-1 p-2 space-y-0.5">
          {sidebarItems.map(item => (
            <button key={item.id} onClick={() => setActivePage(item.id)}
              className={`flex items-center gap-2.5 w-full px-3 py-2 rounded-lg text-sm transition-all ${activePage === item.id ? 'bg-primary/10 text-primary font-medium' : 'text-muted-foreground hover:bg-secondary/50 hover:text-foreground'}`}
              title={sidebarCollapsed ? item.label : undefined}>
              <item.icon className="h-4 w-4 shrink-0" />{!sidebarCollapsed && <span>{item.label}</span>}
            </button>
          ))}
        </nav>
        <div className="p-2 border-t border-border space-y-1">
          {!sidebarCollapsed && profile && (
            <div className="px-3 py-2">
              <p className="text-sm font-medium truncate">{profile.display_name}</p>
              <div className="flex items-center gap-1.5 mt-0.5"><Zap className="h-3 w-3 text-primary" /><span className="text-[10px] text-muted-foreground uppercase tracking-wider font-medium">{profile.plan} plan</span></div>
            </div>
          )}
          <button onClick={() => { signOut(); navigate('/'); }} className="flex items-center gap-2.5 w-full px-3 py-2 rounded-lg text-sm text-muted-foreground hover:bg-secondary/50 hover:text-foreground transition-all">
            <LogOut className="h-4 w-4 shrink-0" />{!sidebarCollapsed && <span>Sair</span>}
          </button>
        </div>
      </aside>

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="h-14 border-b border-border flex items-center justify-between px-4 bg-card/30 backdrop-blur-sm shrink-0">
          <div className="flex items-center gap-3">
            <button onClick={() => setSidebarCollapsed(!sidebarCollapsed)} className="hidden md:block p-1.5 rounded-md text-muted-foreground hover:text-foreground hover:bg-secondary/50"><Menu className="h-4 w-4" /></button>
            {/* Mobile menu */}
            <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)} className="md:hidden p-1.5 rounded-md text-muted-foreground hover:text-foreground"><Menu className="h-4 w-4" /></button>
            <div className="h-4 w-px bg-border hidden md:block" />
            <span className="text-sm font-medium capitalize">{sidebarItems.find(s => s.id === activePage)?.label || 'Overview'}</span>
            {activePage === 'monitor' && (
              <div className="flex items-center gap-1.5 ml-2">
                <span className="w-1.5 h-1.5 rounded-full bg-success animate-pulse" />
                <span className="text-[10px] font-mono text-success">LIVE</span>
              </div>
            )}
          </div>
          <button onClick={() => setShowNewAppModal(true)} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg gradient-primary text-primary-foreground text-xs font-medium hover:opacity-90">
            <Plus className="h-3.5 w-3.5" /><span className="hidden sm:inline">New Server</span>
          </button>
        </header>

        {/* Mobile menu overlay */}
        <AnimatePresence>
          {mobileMenuOpen && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="md:hidden fixed inset-0 z-50 bg-background/90 backdrop-blur-sm" onClick={() => setMobileMenuOpen(false)}>
              <div className="w-56 h-full bg-card border-r border-border p-4 space-y-1" onClick={e => e.stopPropagation()}>
                <div className="flex items-center gap-2 mb-4">
                  <div className="flex h-8 w-8 items-center justify-center rounded-lg gradient-primary"><Server className="h-4 w-4 text-primary-foreground" /></div>
                  <span className="text-base font-bold font-display">Hosta</span>
                </div>
                {sidebarItems.map(item => (
                  <button key={item.id} onClick={() => { setActivePage(item.id); setMobileMenuOpen(false); }}
                    className={`flex items-center gap-2.5 w-full px-3 py-2 rounded-lg text-sm ${activePage === item.id ? 'bg-primary/10 text-primary font-medium' : 'text-muted-foreground hover:bg-secondary/50'}`}>
                    <item.icon className="h-4 w-4" /><span>{item.label}</span>
                  </button>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {activePage === 'servers' ? renderServersPage() : (
          <div className="flex-1 overflow-hidden">{renderPage()}</div>
        )}
      </div>

      {/* New App Modal */}
      <AnimatePresence>
        {showNewAppModal && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/80 backdrop-blur-sm" onClick={() => setShowNewAppModal(false)}>
            <motion.div initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.95, opacity: 0 }}
              className="w-full max-w-md bg-card border border-border rounded-2xl p-6 shadow-2xl" onClick={e => e.stopPropagation()}>
              <h2 className="text-lg font-bold font-display mb-1">Novo Server</h2>
              <p className="text-xs text-muted-foreground mb-5">Configure sua nova aplicação</p>
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-medium mb-1.5 text-muted-foreground">Nome</label>
                  <input value={newApp.name} onChange={e => setNewApp(p => ({ ...p, name: e.target.value }))} className="w-full px-3 py-2.5 rounded-lg bg-input border border-border text-foreground text-sm focus:outline-none focus:ring-1 focus:ring-primary/50" placeholder="meu-bot" />
                </div>
                <div>
                  <label className="block text-xs font-medium mb-1.5 text-muted-foreground">Tipo</label>
                  <div className="grid grid-cols-3 gap-2">
                    {[{ value: 'bot', label: 'Bot', icon: Bot }, { value: 'site', label: 'Website', icon: Globe }, { value: 'api', label: 'API', icon: Plug }].map(opt => (
                      <button key={opt.value} onClick={() => setNewApp(p => ({ ...p, type: opt.value }))}
                        className={`flex flex-col items-center gap-1 p-3 rounded-xl border text-xs transition-all ${newApp.type === opt.value ? 'border-primary bg-primary/10 text-primary' : 'border-border text-muted-foreground hover:bg-secondary/30'}`}>
                        <opt.icon className="h-5 w-5" /><span className="font-medium">{opt.label}</span>
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-medium mb-1.5 text-muted-foreground">Linguagem</label>
                  <select value={newApp.language} onChange={e => setNewApp(p => ({ ...p, language: e.target.value }))}
                    className="w-full px-3 py-2.5 rounded-lg bg-input border border-border text-foreground text-sm focus:outline-none focus:ring-1 focus:ring-primary/50">
                    <option value="node">Node.js</option><option value="python">Python</option><option value="go">Go</option>
                    <option value="html">HTML/CSS</option><option value="next">Next.js</option><option value="vue">Vue</option><option value="react">React</option>
                  </select>
                </div>
                <div className="flex gap-3 pt-2">
                  <button onClick={() => setShowNewAppModal(false)} className="flex-1 py-2.5 rounded-xl border border-border text-sm text-muted-foreground hover:bg-secondary/50">Cancelar</button>
                  <button onClick={createApp} disabled={!newApp.name.trim()} className="flex-1 py-2.5 rounded-xl gradient-primary text-primary-foreground text-sm font-semibold glow-sm hover:opacity-90 disabled:opacity-50">Criar Server</button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default Dashboard;
