import PageLayout from '@/components/PageLayout';
import { motion } from 'framer-motion';
import { Calendar, Clock, ArrowRight, Tag } from 'lucide-react';
import { Link } from 'react-router-dom';

const posts = [
  {
    title: 'Introducing Pterodactyl Integration',
    excerpt: 'Connect your Pterodactyl panel directly to Hosta and manage all your game servers and bots from a single dashboard.',
    date: '2026-02-19',
    readTime: '4 min',
    tag: 'Feature',
    tagColor: 'text-primary bg-primary/10',
  },
  {
    title: 'How to Deploy a Discord Bot in 60 Seconds',
    excerpt: 'Step-by-step guide to deploying your first Discord bot on Hosta with zero configuration and instant uptime.',
    date: '2026-02-15',
    readTime: '3 min',
    tag: 'Tutorial',
    tagColor: 'text-emerald-400 bg-emerald-400/10',
  },
  {
    title: 'New Pricing: More Resources, Lower Prices',
    excerpt: 'We\'ve completely revamped our pricing structure to give you more RAM, CPU and storage at every tier.',
    date: '2026-02-10',
    readTime: '2 min',
    tag: 'Announcement',
    tagColor: 'text-amber-400 bg-amber-400/10',
  },
  {
    title: 'Auto-Scaling for Pro and Advanced Plans',
    excerpt: 'Your applications now automatically scale resources based on demand. No configuration needed — it just works.',
    date: '2026-02-05',
    readTime: '5 min',
    tag: 'Feature',
    tagColor: 'text-primary bg-primary/10',
  },
  {
    title: 'Security Update: Enhanced DDoS Protection',
    excerpt: 'Our new edge-level DDoS mitigation protects all hosted applications with zero latency impact.',
    date: '2026-01-28',
    readTime: '3 min',
    tag: 'Security',
    tagColor: 'text-red-400 bg-red-400/10',
  },
  {
    title: 'Building a REST API with Hosta',
    excerpt: 'Learn how to build and deploy a production-ready REST API using Node.js and our hosting infrastructure.',
    date: '2026-01-20',
    readTime: '6 min',
    tag: 'Tutorial',
    tagColor: 'text-emerald-400 bg-emerald-400/10',
  },
];

const Blog = () => (
  <PageLayout>
    <section className="py-20">
      <div className="container mx-auto px-4 max-w-4xl">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-12">
          <h1 className="text-3xl md:text-5xl font-bold font-display mb-3">Blog</h1>
          <p className="text-muted-foreground">Updates, tutorials and news from the Hosta team</p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {posts.map((post, i) => (
            <motion.article
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              className="group bg-card/50 border border-border/50 rounded-xl p-5 hover:border-primary/20 transition-all cursor-pointer"
            >
              <div className="flex items-center gap-2 mb-3">
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium ${post.tagColor}`}>{post.tag}</span>
                <div className="flex items-center gap-1 text-[11px] text-muted-foreground">
                  <Calendar className="h-3 w-3" />
                  {post.date}
                </div>
                <div className="flex items-center gap-1 text-[11px] text-muted-foreground">
                  <Clock className="h-3 w-3" />
                  {post.readTime}
                </div>
              </div>
              <h2 className="text-base font-bold font-display mb-2 group-hover:text-primary transition-colors">{post.title}</h2>
              <p className="text-xs text-muted-foreground leading-relaxed mb-3">{post.excerpt}</p>
              <span className="inline-flex items-center gap-1 text-xs text-primary font-medium group-hover:gap-2 transition-all">
                Read more <ArrowRight className="h-3 w-3" />
              </span>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  </PageLayout>
);

export default Blog;
