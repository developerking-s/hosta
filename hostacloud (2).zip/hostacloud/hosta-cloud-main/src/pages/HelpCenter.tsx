import PageLayout from '@/components/PageLayout';
import { useI18n } from '@/lib/i18n';
import { motion } from 'framer-motion';
import { MessageCircle, Book, Mail, HelpCircle, LifeBuoy, FileQuestion, ExternalLink } from 'lucide-react';

const faqs = [
  { q: 'Como faço deploy do meu bot?', a: 'Crie um serviço do tipo "Bot" no dashboard, envie seus arquivos ou conecte via Git. Configure as variáveis de ambiente, defina o comando de start e clique em executar.' },
  { q: 'Quais linguagens são suportadas?', a: 'Node.js (Discord.js, Express), Python (Discord.py, Flask), Go, e aplicações web (React, Next.js, Vue, Vite, HTML/CSS).' },
  { q: 'O que acontece se meu bot crashar?', a: 'A Hosta detecta a falha e reinicia automaticamente. Logs em tempo real ajudam a identificar a causa.' },
  { q: 'Como configuro variáveis de ambiente?', a: 'No dashboard, acesse as configurações da sua aplicação e adicione suas variáveis .env. Elas ficam seguras e não aparecem no código.' },
  { q: 'Como funciona o plano gratuito?', a: '512MB RAM, 1GB armazenamento, 1 app. Ideal para testar. Sem cartão de crédito.' },
  { q: 'Posso migrar de outra plataforma?', a: 'Sim. Envie seus arquivos, configure variáveis de ambiente e pronto.' },
  { q: 'Como usar a API da Hosta?', a: 'Gere um token na página de configurações e use nossa API REST para gerenciar apps, deploys, logs e arquivos programaticamente.' },
  { q: 'A Hosta tem integração com Discord?', a: 'Sim. Bots podem se conectar ao Discord Gateway normalmente. Suportamos Discord.js e Discord.py nativamente.' },
  { q: 'Como funciona o deploy via Git?', a: 'Conecte seu repositório. A cada push na branch configurada, o deploy é automático.' },
  { q: 'O que é o console em tempo real?', a: 'Um terminal no dashboard que mostra os logs da sua aplicação em tempo real via WebSocket.' },
];

const guides = [
  { title: 'Hospedar bot Discord.js', desc: 'Guia completo de deploy de bot Discord em Node.js', icon: '🤖' },
  { title: 'Hospedar bot Discord.py', desc: 'Deploy de bot Python no servidor Hosta', icon: '🐍' },
  { title: 'Deploy de site Next.js', desc: 'Como hospedar uma aplicação Next.js', icon: '⚡' },
  { title: 'API REST com Express', desc: 'Crie e hospede uma API completa', icon: '🔧' },
  { title: 'Variáveis de ambiente', desc: 'Configure .env para sua aplicação', icon: '🔐' },
  { title: 'Deploy via Git', desc: 'Integração contínua com repositório', icon: '📦' },
];

const HelpCenter = () => {
  const { t } = useI18n();

  return (
    <PageLayout>
      <section className="py-24">
        <div className="container mx-auto px-4">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-16">
            <h1 className="text-4xl md:text-6xl font-bold font-display mb-4">Central de Ajuda</h1>
            <p className="text-lg text-muted-foreground">Tutoriais, guias e respostas para suas dúvidas</p>
          </motion.div>

          {/* Contact channels */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-20">
            {[
              { icon: MessageCircle, title: 'Discord', desc: 'Comunidade ativa com suporte rápido', link: '#', color: 'bg-[hsl(235,86%,65%)]' },
              { icon: Book, title: 'Documentação', desc: 'API, SDK e guias técnicos', link: '/docs', color: 'gradient-primary' },
              { icon: Mail, title: 'Email', desc: 'support@hosta.app', link: 'mailto:support@hosta.app', color: 'bg-success' },
            ].map((ch, i) => (
              <motion.a
                key={i}
                href={ch.link}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className="surface-card p-6 hover:border-primary/30 transition-all group"
              >
                <div className={`w-12 h-12 rounded-xl ${ch.color} flex items-center justify-center mb-4`}>
                  <ch.icon className="h-6 w-6 text-primary-foreground" />
                </div>
                <h3 className="text-lg font-semibold font-display mb-1">{ch.title}</h3>
                <p className="text-sm text-muted-foreground">{ch.desc}</p>
              </motion.a>
            ))}
          </div>

          {/* Guides */}
          <div className="max-w-4xl mx-auto mb-20">
            <div className="flex items-center gap-2 mb-6">
              <LifeBuoy className="h-5 w-5 text-primary" />
              <h2 className="text-2xl font-bold font-display">Guias Rápidos</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {guides.map((guide, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 + i * 0.05 }}
                  className="surface-card p-5 hover:border-primary/30 transition-all cursor-pointer group"
                >
                  <span className="text-2xl mb-3 block">{guide.icon}</span>
                  <h3 className="font-semibold font-display text-sm mb-1 group-hover:text-primary transition-colors">{guide.title}</h3>
                  <p className="text-xs text-muted-foreground">{guide.desc}</p>
                </motion.div>
              ))}
            </div>
          </div>

          {/* FAQ */}
          <div className="max-w-3xl mx-auto">
            <div className="flex items-center gap-2 mb-8">
              <FileQuestion className="h-5 w-5 text-primary" />
              <h2 className="text-2xl font-bold font-display">Perguntas Frequentes</h2>
            </div>
            <div className="space-y-3">
              {faqs.map((faq, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5 + i * 0.03 }}
                  className="surface-card p-5"
                >
                  <h3 className="font-semibold font-display text-sm mb-2">{faq.q}</h3>
                  <p className="text-xs text-muted-foreground leading-relaxed">{faq.a}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </PageLayout>
  );
};

export default HelpCenter;
