import PageLayout from '@/components/PageLayout';
import { motion } from 'framer-motion';
import { Code2, BookOpen, Terminal, ExternalLink } from 'lucide-react';

const docs = [
  {
    title: 'Discord.js',
    desc: 'Biblioteca para criar bots Discord em Node.js. A mais popular e completa.',
    url: 'https://discord.js.org/docs',
    language: 'Node.js',
  },
  {
    title: 'Discord.py',
    desc: 'Wrapper Python assíncrono para a API do Discord. Moderna e eficiente.',
    url: 'https://discordpy.readthedocs.io/',
    language: 'Python',
  },
  {
    title: 'Discord API',
    desc: 'Documentação oficial da API REST e Gateway do Discord.',
    url: 'https://discord.com/developers/docs',
    language: 'REST',
  },
  {
    title: 'Express.js',
    desc: 'Framework web rápido, minimalista e flexível para Node.js.',
    url: 'https://expressjs.com/',
    language: 'Node.js',
  },
  {
    title: 'Next.js',
    desc: 'Framework React com SSR, SSG e rotas API integradas.',
    url: 'https://nextjs.org/docs',
    language: 'React',
  },
  {
    title: 'Vue.js',
    desc: 'Framework JavaScript progressivo para interfaces de usuário.',
    url: 'https://vuejs.org/guide/',
    language: 'JavaScript',
  },
  {
    title: 'Flask',
    desc: 'Micro framework web em Python. Simples e extensível.',
    url: 'https://flask.palletsprojects.com/',
    language: 'Python',
  },
  {
    title: 'Go net/http',
    desc: 'Pacote HTTP padrão do Go para criar servidores web.',
    url: 'https://pkg.go.dev/net/http',
    language: 'Go',
  },
];

const apiEndpoints = [
  { method: 'GET', path: '/api/v1/apps', desc: 'Listar todas as aplicações' },
  { method: 'POST', path: '/api/v1/apps', desc: 'Criar nova aplicação' },
  { method: 'GET', path: '/api/v1/apps/:id', desc: 'Detalhes de uma aplicação' },
  { method: 'PATCH', path: '/api/v1/apps/:id', desc: 'Atualizar aplicação' },
  { method: 'DELETE', path: '/api/v1/apps/:id', desc: 'Excluir aplicação' },
  { method: 'POST', path: '/api/v1/apps/:id/deploy', desc: 'Fazer deploy' },
  { method: 'POST', path: '/api/v1/apps/:id/start', desc: 'Iniciar aplicação' },
  { method: 'POST', path: '/api/v1/apps/:id/stop', desc: 'Parar aplicação' },
  { method: 'GET', path: '/api/v1/apps/:id/logs', desc: 'Buscar logs' },
  { method: 'GET', path: '/api/v1/apps/:id/files', desc: 'Listar arquivos' },
];

const methodColor = (m: string) => {
  switch (m) {
    case 'GET': return 'text-success bg-success/10';
    case 'POST': return 'text-primary bg-primary/10';
    case 'PATCH': return 'text-warning bg-warning/10';
    case 'DELETE': return 'text-destructive bg-destructive/10';
    default: return 'text-muted-foreground bg-secondary';
  }
};

const ApiDocs = () => (
  <PageLayout>
    <section className="py-24">
      <div className="container mx-auto px-4">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-16">
          <h1 className="text-4xl md:text-6xl font-bold font-display mb-4">Documentação</h1>
          <p className="text-lg text-muted-foreground">API da Hosta e referências das bibliotecas suportadas</p>
        </motion.div>

        {/* API Reference */}
        <div className="max-w-4xl mx-auto mb-20">
          <div className="flex items-center gap-2 mb-6">
            <Terminal className="h-5 w-5 text-primary" />
            <h2 className="text-2xl font-bold font-display">API REST</h2>
          </div>
          <p className="text-sm text-muted-foreground mb-6">Base URL: <code className="px-2 py-0.5 rounded bg-secondary font-mono text-xs">https://api.hosta.app/v1</code></p>

          <div className="surface-card overflow-hidden">
            {apiEndpoints.map((ep, i) => (
              <div key={i} className="flex items-center gap-4 px-4 py-3 border-b border-border last:border-0 hover:bg-secondary/20 transition-colors">
                <span className={`px-2 py-0.5 rounded text-xs font-mono font-bold ${methodColor(ep.method)}`}>{ep.method}</span>
                <code className="text-sm font-mono text-foreground flex-1">{ep.path}</code>
                <span className="text-xs text-muted-foreground hidden sm:block">{ep.desc}</span>
              </div>
            ))}
          </div>
        </div>

        {/* SDK Docs */}
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center gap-2 mb-6">
            <BookOpen className="h-5 w-5 text-primary" />
            <h2 className="text-2xl font-bold font-display">Bibliotecas & Frameworks</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {docs.map((doc, i) => (
              <motion.a
                key={i}
                href={doc.url}
                target="_blank"
                rel="noopener noreferrer"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                className="surface-card p-5 hover:border-primary/30 transition-all group"
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <Code2 className="h-4 w-4 text-primary" />
                    <h3 className="font-semibold font-display text-sm">{doc.title}</h3>
                  </div>
                  <ExternalLink className="h-3.5 w-3.5 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
                <p className="text-xs text-muted-foreground mb-2">{doc.desc}</p>
                <span className="text-xs px-2 py-0.5 rounded bg-secondary text-muted-foreground font-mono">{doc.language}</span>
              </motion.a>
            ))}
          </div>
        </div>
      </div>
    </section>
  </PageLayout>
);

export default ApiDocs;
