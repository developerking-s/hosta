import PageLayout from '@/components/PageLayout';
import { useI18n } from '@/lib/i18n';
import { motion } from 'framer-motion';

const Terms = () => {
  const { t } = useI18n();

  return (
    <PageLayout>
      <section className="py-24">
        <div className="container mx-auto px-4 max-w-4xl">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <h1 className="text-4xl font-bold font-display mb-8">{t.legal.terms}</h1>

            <div className="surface-card p-8 space-y-8">
              <div>
                <h2 className="text-xl font-bold font-display mb-4">1. Aceitação dos Termos</h2>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  Ao utilizar a plataforma Hosta, você concorda com estes termos de serviço. Se não concordar, não utilize nossos serviços.
                </p>
              </div>

              <div>
                <h2 className="text-xl font-bold font-display mb-4">2. Uso da Plataforma</h2>
                <div className="text-sm text-muted-foreground space-y-2 leading-relaxed">
                  <p>Você se compromete a utilizar a plataforma de forma responsável e dentro da legalidade. É proibido:</p>
                  <ul className="list-disc list-inside space-y-1 ml-2">
                    <li>Hospedar conteúdo ilegal ou malicioso</li>
                    <li>Realizar ataques DDoS ou spam</li>
                    <li>Violar direitos autorais ou propriedade intelectual</li>
                    <li>Compartilhar credenciais de acesso</li>
                  </ul>
                </div>
              </div>

              <div>
                <h2 className="text-xl font-bold font-display mb-4">3. Planos e Pagamentos</h2>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  Os planos são cobrados mensalmente. O não pagamento pode resultar na suspensão do serviço. Reembolsos são avaliados caso a caso.
                </p>
              </div>

              <div>
                <h2 className="text-xl font-bold font-display mb-4">4. Disponibilidade</h2>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  Nos esforçamos para manter 99.9% de uptime, mas não garantimos disponibilidade ininterrupta. Manutenções programadas serão comunicadas com antecedência.
                </p>
              </div>

              <div>
                <h2 className="text-xl font-bold font-display mb-4">5. Encerramento</h2>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  Reservamo-nos o direito de suspender ou encerrar contas que violem estes termos. Você pode cancelar sua conta a qualquer momento.
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </PageLayout>
  );
};

export default Terms;
