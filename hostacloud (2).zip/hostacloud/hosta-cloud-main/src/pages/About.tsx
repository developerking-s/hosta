import PageLayout from '@/components/PageLayout';
import { useI18n } from '@/lib/i18n';
import { motion } from 'framer-motion';
import { Target, Users, Globe, Zap, Shield, Eye, Heart, Code2, Rocket, Server } from 'lucide-react';

const About = () => {
  const { t } = useI18n();

  const stats = [
    { value: '1,247+', label: 'Apps Hospedados' },
    { value: '500+', label: 'Desenvolvedores' },
    { value: '99.97%', label: 'Uptime' },
    { value: '10M+', label: 'Requests/mês' },
  ];

  const values = [
    { icon: Eye, title: 'Transparência', desc: 'Sem promessas irreais. Sem limites escondidos. Sem painéis confusos.' },
    { icon: Heart, title: 'Comunidade', desc: 'Feita por devs, para devs. Ouvimos e construímos junto.' },
    { icon: Shield, title: 'Confiança', desc: 'Infraestrutura robusta com monitoramento 24/7.' },
    { icon: Rocket, title: 'Inovação', desc: 'Sempre evoluindo para oferecer a melhor experiência.' },
  ];

  const team = [
    { name: 'Equipe Hosta', role: 'Desenvolvimento', icon: Code2 },
    { name: 'Infraestrutura', role: 'DevOps & SRE', icon: Server },
    { name: 'Suporte', role: 'Comunidade', icon: Users },
  ];

  return (
    <PageLayout>
      <section className="py-24">
        <div className="container mx-auto px-4">
          {/* Hero */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-20">
            <span className="text-xs font-mono text-primary uppercase tracking-widest mb-3 block">Sobre nós</span>
            <h1 className="text-4xl md:text-6xl font-bold font-display mb-4">{t.about.title}</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Infraestrutura moderna e acessível para bots, sites e APIs.
            </p>
          </motion.div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-20">
            {stats.map((stat, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className="bg-card border border-border rounded-2xl p-6 text-center"
              >
                <div className="text-2xl md:text-3xl font-bold font-display gradient-text">{stat.value}</div>
                <div className="text-xs text-muted-foreground mt-1 font-mono uppercase tracking-wider">{stat.label}</div>
              </motion.div>
            ))}
          </div>

          {/* Mission */}
          <div className="max-w-4xl mx-auto mb-20">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="bg-card border border-border rounded-2xl p-8 md:p-12">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 rounded-xl gradient-primary flex items-center justify-center">
                  <Target className="h-6 w-6 text-primary-foreground" />
                </div>
                <h2 className="text-2xl font-bold font-display">{t.about.mission}</h2>
              </div>
              <p className="text-muted-foreground leading-relaxed text-base mb-4">{t.about.missionText}</p>
              <p className="text-muted-foreground leading-relaxed text-base">
                Diferente de hospedagens genéricas, a Hosta foi pensada desde o início para rodar bots de Discord, sites, APIs e serviços backend de forma simples, escalável e sem limitações artificiais. Acreditamos que todo desenvolvedor merece infraestrutura de qualidade, independente do orçamento.
              </p>
            </motion.div>
          </div>

          {/* Values */}
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-12">
            <span className="text-xs font-mono text-primary uppercase tracking-widest mb-3 block">Valores</span>
            <h2 className="text-3xl md:text-4xl font-bold font-display">O que nos guia</h2>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 mb-20">
            {values.map((value, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08 }}
                className="bg-card border border-border rounded-2xl p-6 hover:border-primary/30 transition-all group"
              >
                <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                  <value.icon className="h-5 w-5 text-primary" />
                </div>
                <h3 className="font-bold font-display text-base mb-1">{value.title}</h3>
                <p className="text-sm text-muted-foreground">{value.desc}</p>
              </motion.div>
            ))}
          </div>

          {/* Team */}
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-12">
            <span className="text-xs font-mono text-primary uppercase tracking-widest mb-3 block">Equipe</span>
            <h2 className="text-3xl md:text-4xl font-bold font-display">Quem está por trás</h2>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-4">
            {team.map((member, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="bg-card border border-border rounded-2xl p-8 text-center group hover:border-primary/30 transition-all"
              >
                <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-4 group-hover:bg-primary/20 transition-colors">
                  <member.icon className="h-8 w-8 text-primary" />
                </div>
                <h3 className="font-bold font-display text-lg mb-0.5">{member.name}</h3>
                <p className="text-sm text-muted-foreground">{member.role}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </PageLayout>
  );
};

export default About;
