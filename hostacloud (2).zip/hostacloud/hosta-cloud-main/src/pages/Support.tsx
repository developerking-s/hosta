import PageLayout from '@/components/PageLayout';
import { useI18n } from '@/lib/i18n';
import { motion } from 'framer-motion';
import { MessageCircle, Book, Mail, HelpCircle } from 'lucide-react';

const Support = () => {
  const { t } = useI18n();

  const channels = [
    { icon: MessageCircle, title: t.support.discord, desc: t.support.discordDesc, link: '#', color: 'bg-[hsl(235,86%,65%)]' },
    { icon: Book, title: t.support.docs, desc: t.support.docsDesc, link: '#', color: 'gradient-primary' },
    { icon: Mail, title: t.support.email, desc: t.support.emailDesc, link: 'mailto:support@hosta.app', color: 'bg-success' },
  ];

  const faqs = [
    { q: 'Como faço deploy do meu bot?', a: 'Crie um serviço do tipo "Bot", envie seus arquivos pelo painel ou via Git. Configure as variáveis de ambiente, defina o comando de start e clique em executar. Detectamos automaticamente o runtime.' },
    { q: 'Quais linguagens são suportadas?', a: 'Node.js (Discord.js, Express, Fastify), Python (Discord.py, Flask), Go, e qualquer aplicação web (HTML, CSS, React, Next.js, Vue, Vite).' },
    { q: 'O que acontece se meu bot crashar?', a: 'A Hosta detecta a falha automaticamente e reinicia o processo. Você pode acompanhar os logs em tempo real para identificar a causa.' },
    { q: 'Posso configurar variáveis de ambiente?', a: 'Sim. Configure suas variáveis .env diretamente pelo painel, sem expor no código. Elas ficam disponíveis no runtime da sua aplicação.' },
    { q: 'Como funciona o plano gratuito?', a: 'O plano Free inclui 512MB de RAM, 1GB de armazenamento e 1 aplicação. Ideal para testar a plataforma e hospedar projetos menores.' },
    { q: 'Posso migrar de outra plataforma?', a: 'Sim. Envie seus arquivos, configure as variáveis de ambiente e pronto. Sem processo complicado.' },
    { q: 'A Hosta hospeda sites estáticos?', a: 'Sim. Sites em HTML/CSS/JS e frameworks como React, Next.js, Vue e Vite. Builds automáticos e deploy simplificado.' },
    { q: 'Como funciona o deploy via Git?', a: 'Conecte seu repositório ao painel. A cada push na branch configurada, o deploy é feito automaticamente.' },
  ];

  return (
    <PageLayout>
      <section className="py-24">
        <div className="container mx-auto px-4">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-16">
            <h1 className="text-4xl md:text-6xl font-bold font-display mb-4">{t.support.title}</h1>
            <p className="text-lg text-muted-foreground">{t.support.subtitle}</p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-20">
            {channels.map((ch, i) => (
              <motion.a
                key={i}
                href={ch.link}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className="surface-card p-6 hover:border-primary/30 transition-all group"
              >
                <div className={`w-12 h-12 rounded-xl ${ch.color} flex items-center justify-center mb-4`}>
                  <ch.icon className="h-6 w-6 text-primary-foreground" />
                </div>
                <h3 className="text-lg font-semibold font-display mb-1">{ch.title}</h3>
                <p className="text-sm text-muted-foreground">{ch.desc}</p>
              </motion.a>
            ))}
          </div>

          {/* FAQ */}
          <div className="max-w-3xl mx-auto">
            <div className="flex items-center gap-2 mb-8">
              <HelpCircle className="h-5 w-5 text-primary" />
              <h2 className="text-2xl font-bold font-display">{t.support.faqTitle}</h2>
            </div>
            <div className="space-y-4">
              {faqs.map((faq, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 + i * 0.05 }}
                  className="surface-card p-5"
                >
                  <h3 className="font-semibold font-display mb-2">{faq.q}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{faq.a}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </PageLayout>
  );
};

export default Support;
