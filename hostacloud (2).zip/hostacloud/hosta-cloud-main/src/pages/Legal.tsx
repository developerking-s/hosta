import PageLayout from '@/components/PageLayout';
import { useI18n } from '@/lib/i18n';
import { motion } from 'framer-motion';

const Legal = () => {
  const { t } = useI18n();

  return (
    <PageLayout>
      <section className="py-24">
        <div className="container mx-auto px-4 max-w-4xl">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <h1 className="text-4xl font-bold font-display mb-8">{t.legal.title}</h1>

            <div className="surface-card p-8 space-y-8">
              <div>
                <h2 className="text-xl font-bold font-display mb-4">{t.legal.privacy}</h2>
                <div className="text-sm text-muted-foreground space-y-3 leading-relaxed">
                  <p>A Hosta se compromete a proteger sua privacidade. Esta política descreve como coletamos, usamos e protegemos suas informações pessoais.</p>
                  <p><strong className="text-foreground">Dados coletados:</strong> Coletamos informações necessárias para fornecer nossos serviços, incluindo nome, email, dados de uso e informações de pagamento.</p>
                  <p><strong className="text-foreground">Uso dos dados:</strong> Seus dados são utilizados exclusivamente para fornecer e melhorar nossos serviços, processar pagamentos e comunicar atualizações importantes.</p>
                  <p><strong className="text-foreground">Segurança:</strong> Utilizamos criptografia de ponta e práticas de segurança da indústria para proteger seus dados.</p>
                  <p><strong className="text-foreground">Cookies:</strong> Utilizamos cookies essenciais para o funcionamento da plataforma e cookies analíticos para melhorar a experiência.</p>
                </div>
              </div>

              <div className="border-t border-border pt-8">
                <h2 className="text-xl font-bold font-display mb-4">{t.legal.cookies}</h2>
                <div className="text-sm text-muted-foreground space-y-3 leading-relaxed">
                  <p>Utilizamos cookies para melhorar sua experiência na plataforma. Cookies essenciais são necessários para o funcionamento básico do site.</p>
                  <p>Você pode gerenciar suas preferências de cookies nas configurações do navegador a qualquer momento.</p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </PageLayout>
  );
};

export default Legal;
