import { Link, useLocation } from 'react-router-dom';
import { useEffect } from 'react';
import { motion } from 'framer-motion';
import { Server, ArrowLeft, Home } from 'lucide-react';

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error('404 Error:', location.pathname);
  }, [location.pathname]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-background px-4 relative overflow-hidden">
      {/* Background glow */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/3 left-1/2 -translate-x-1/2 w-[500px] h-[500px] rounded-full bg-primary/5 blur-[120px]" />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="text-center relative z-10 max-w-md"
      >
        <div className="flex justify-center mb-6">
          <div className="w-20 h-20 rounded-2xl bg-secondary/30 flex items-center justify-center border border-border/30">
            <Server className="h-10 w-10 text-muted-foreground/30" />
          </div>
        </div>

        <motion.h1
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.1 }}
          className="text-7xl md:text-9xl font-bold font-display gradient-text mb-4"
        >
          404
        </motion.h1>

        <h2 className="text-xl font-semibold font-display mb-2">Server Not Found</h2>
        <p className="text-sm text-muted-foreground mb-8 leading-relaxed">
          The page <code className="px-1.5 py-0.5 rounded bg-secondary text-xs font-mono text-foreground">{location.pathname}</code> doesn't exist or has been moved.
        </p>

        <div className="flex items-center justify-center gap-3">
          <button onClick={() => window.history.back()} className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl border border-border text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-secondary/50 transition-all">
            <ArrowLeft className="h-4 w-4" />
            Go Back
          </button>
          <Link to="/" className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl gradient-primary text-primary-foreground text-sm font-semibold hover:opacity-90 transition-all glow-sm">
            <Home className="h-4 w-4" />
            Home
          </Link>
        </div>
      </motion.div>
    </div>
  );
};

export default NotFound;
