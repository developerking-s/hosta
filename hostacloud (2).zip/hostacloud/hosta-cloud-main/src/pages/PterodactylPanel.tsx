import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import PageLayout from '@/components/PageLayout';
import { PanelManager } from '@/components/PanelManager';
import { ServerList } from '@/components/ServerList';
import { VPSProviderList } from '@/components/VPSProviderList';
import { ServerMonitoringDashboard } from '@/components/ServerMonitoringDashboard';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { PanelInstance } from '@/services/pterodactyl';

export default function PterodactylPanel() {
  const [selectedPanel, setSelectedPanel] = useState<PanelInstance | null>(null);

  return (
    <PageLayout>
      <div className="space-y-8 py-8">
        {/* Hero Section */}
        <div className="text-center space-y-4">
          <h1 className="text-4xl font-bold">Pterodactyl Control Panel</h1>
          <p className="text-xl text-muted-foreground">
            Manage your Pterodactyl servers and VPS instances in one place
          </p>
        </div>

        {/* Main Tabs */}
        <Tabs defaultValue="panels" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="panels">Panels</TabsTrigger>
            <TabsTrigger value="servers" disabled={!selectedPanel}>
              Servers
            </TabsTrigger>
            <TabsTrigger value="vps">Free VPS</TabsTrigger>
            <TabsTrigger value="monitoring">Monitoring</TabsTrigger>
          </TabsList>

          {/* Panels Tab */}
          <TabsContent value="panels" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Pterodactyl Panel Management</CardTitle>
                <CardDescription>
                  Connect to your Pterodactyl panel instances to manage servers and resources
                </CardDescription>
              </CardHeader>
              <CardContent>
                <PanelManager 
                  onPanelSelect={setSelectedPanel}
                />
              </CardContent>
            </Card>
          </TabsContent>

          {/* Servers Tab */}
          <TabsContent value="servers" className="space-y-4">
            {selectedPanel ? (
              <Card>
                <CardHeader>
                  <CardTitle>Servers on {selectedPanel.name}</CardTitle>
                  <CardDescription>
                    View and manage all servers on this panel
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ServerList panelId={selectedPanel.id} />
                </CardContent>
              </Card>
            ) : (
              <Card>
                <CardContent className="pt-6 text-center text-muted-foreground">
                  Select a panel first to view its servers
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* VPS Providers Tab */}
          <TabsContent value="vps" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Free VPS Providers</CardTitle>
                <CardDescription>
                  Discover and connect to free VPS hosting providers
                </CardDescription>
              </CardHeader>
              <CardContent>
                <VPSProviderList />
              </CardContent>
            </Card>
          </TabsContent>

          {/* Monitoring Tab */}
          <TabsContent value="monitoring" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Server Monitoring Dashboard</CardTitle>
                <CardDescription>
                  Real-time monitoring of your server resources
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ServerMonitoringDashboard autoRefresh={true} refreshInterval={30000} />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Info Cards */}
        <div className="grid gap-4 md:grid-cols-3 mt-12">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">🚀 Easy Setup</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Connect to your Pterodactyl panels with just a URL, no API keys needed
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">💰 Free Hosting</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Discover and manage free VPS providers all in one place
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">📊 Real-time Monitoring</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Monitor CPU, memory, and disk usage across all your servers
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </PageLayout>
  );
}
