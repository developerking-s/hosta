import PageLayout from '@/components/PageLayout';
import HeroSection from '@/components/HeroSection';
import FeaturesSection from '@/components/FeaturesSection';
import HowItWorksSection from '@/components/HowItWorksSection';
import PhilosophySection from '@/components/PhilosophySection';
import PricingCard from '@/components/PricingCard';
import { useI18n } from '@/lib/i18n';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowRight, MessageCircle } from 'lucide-react';

const Index = () => {
  const { t } = useI18n();

  const plans = [
    { name: t.plans.free, price: '0', ram: '512 MB', cpu: '0.5', storage: '1 GB', apps: '1', features: ['Deploy automático', 'SSL gratuito', 'Logs em tempo real', 'Reinício automático'] },
    { name: t.plans.basic, price: '9.90', ram: '1 GB', cpu: '1', storage: '5 GB', apps: '3', features: ['Tudo do Free', 'Domínio custom', 'Deploy via Git', 'Suporte por email'] },
    { name: t.plans.standard, price: '24.90', ram: '2 GB', cpu: '2', storage: '10 GB', apps: '5', features: ['Tudo do Basic', 'Backup diário', 'Suporte prioritário', 'Webhooks'], popular: true },
    { name: t.plans.pro, price: '49.90', ram: '4 GB', cpu: '4', storage: '25 GB', apps: '10', features: ['Tudo do Standard', 'Auto-scaling', 'API avançada', 'SLA 99.9%'] },
    { name: t.plans.advanced, price: '99.90', ram: '8 GB', cpu: '8', storage: '50 GB', apps: '25', features: ['Tudo do Pro', 'Servidor dedicado', 'SLA 99.99%', 'IP dedicado', 'Suporte 24/7'] },
  ];

  return (
    <PageLayout>
      <HeroSection />
      <FeaturesSection />
      <HowItWorksSection />

      {/* Pricing */}
      <section className="py-24">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <span className="text-xs font-mono text-primary uppercase tracking-widest mb-3 block">Preços</span>
            <h2 className="text-3xl md:text-5xl font-bold font-display">
              Preços honestos. <span className="text-muted-foreground">Sem surpresas.</span>
            </h2>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            {plans.map((plan, i) => (
              <motion.div key={i} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.06 }}>
                <PricingCard {...plan} />
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <PhilosophySection />

      {/* CTA */}
      <section className="py-24">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="relative bg-card border border-border rounded-3xl p-12 md:p-20 text-center overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-primary/8 via-transparent to-accent/5" />
            <div className="absolute top-0 right-0 w-[400px] h-[400px] rounded-full bg-primary/5 blur-[120px]" />
            
            <div className="relative z-10">
              <h2 className="text-3xl md:text-5xl font-bold font-display mb-4">
                Pronto para começar?
              </h2>
              <p className="text-muted-foreground mb-8 max-w-lg mx-auto text-lg">
                Junte-se a milhares de desenvolvedores que confiam na Hosta para hospedar seus projetos.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
                <Link
                  to="/register"
                  className="group inline-flex items-center gap-2 px-8 py-4 rounded-xl gradient-primary text-primary-foreground font-bold text-base glow transition-all hover:opacity-90"
                >
                  Experimentar Grátis
                  <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                </Link>
                <a
                  href="https://discord.gg/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 px-6 py-4 rounded-xl border border-border bg-card/50 text-foreground font-medium text-sm hover:bg-card transition-all"
                >
                  <MessageCircle className="h-4 w-4" />
                  Comunidade
                </a>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </PageLayout>
  );
};

export default Index;
