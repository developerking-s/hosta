declare module 'express' {
  interface Request {
    method: string;
    path: string;
    body: any;
    query: any;
    params: any;
    headers: any;
  }

  interface Response {
    status(code: number): Response;
    json(data: any): Response;
    send(data: any): Response;
    end(): void;
  }

  type NextFunction = (err?: any) => void;
  type Handler = (req: any, res: any, next?: any) => any;

  interface Application {
    use(handler: any): Application;
    use(path: string, handler: any): Application;
    get(path: string, ...handlers: any[]): Application;
    post(path: string, ...handlers: any[]): Application;
    put(path: string, ...handlers: any[]): Application;
    delete(path: string, ...handlers: any[]): Application;
    patch(path: string, ...handlers: any[]): Application;
    listen(port: number | string, callback?: () => void): void;
  }

  interface Router extends Application {}

  function express(): Application;
  
  namespace express {
    function Router(): Router;
    function json(options?: any): Handler;
    function urlencoded(options?: any): Handler;
    function static(root: string): Handler;
  }
  
  export = express;
}
