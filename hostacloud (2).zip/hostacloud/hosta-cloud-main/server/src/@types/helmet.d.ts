declare module 'helmet' {
  function helmet(options?: any): any;
  export = helmet;
}
