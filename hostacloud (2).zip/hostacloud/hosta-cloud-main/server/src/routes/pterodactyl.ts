import express from 'express';
import axios from 'axios';
import { v4 as uuidv4 } from 'uuid';

export const pterodactylRoutes: any = express.Router();

// Cache for panel instances
interface PanelInstance {
  url: string;
  name: string;
  status: 'online' | 'offline';
  lastChecked: Date;
  stats?: {
    servers: number;
    nodes: number;
    users: number;
  };
}

const panels: Map<string, PanelInstance> = new Map();

// Initialize with default panels
const initializePanels = () => {
  const defaultPanels = [
    'https://panel.pterodactyl.io',
    'https://demo.pterodactyl.io',
  ];

  defaultPanels.forEach((urlString) => {
    try {
      const urlObj = new URL(urlString);
      panels.set(uuidv4(), {
        url: urlString,
        name: urlObj.hostname || 'Pterodactyl Panel',
        status: 'offline',
        lastChecked: new Date(),
      });
    } catch (error) {
      console.error('Invalid URL:', urlString);
    }
  });
};

initializePanels();

/**
 * Add a new Pterodactyl panel instance
 */
pterodactylRoutes.post('/panels/add', async (req: any, res: any) => {
  try {
    const { url, name } = req.body;

    if (!url) {
      return res.status(400).json({
        success: false,
        error: 'Panel URL is required',
      });
    }

    // Validate URL format
    try {
      new URL(url);
    } catch (error) {
      return res.status(400).json({
        success: false,
        error: 'Invalid URL format',
      });
    }

    const instanceId = uuidv4();
    let panelName = name;
    if (!panelName) {
      try {
        const urlObj = new URL(url);
        panelName = urlObj.hostname || 'Pterodactyl Panel';
      } catch (error) {
        panelName = 'Pterodactyl Panel';
      }
    }
    panels.set(instanceId, {
      url,
      name: panelName,
      status: 'offline',
      lastChecked: new Date(),
    })

    res.json({
      success: true,
      instanceId,
      panel: panels.get(instanceId),
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * Get all Pterodactyl panel instances
 */
pterodactylRoutes.get('/panels', (req: any, res: any) => {
  const panelList = Array.from(panels.entries()).map(([id, panel]) => ({
    id,
    ...panel,
  }));

  res.json({
    success: true,
    panels: panelList,
    total: panelList.length,
  });
});

/**
 * Check panel status and fetch info
 */
pterodactylRoutes.get('/panels/:instanceId/status', async (req: any, res: any) => {
  try {
    const { instanceId } = req.params;
    const panel = panels.get(instanceId);

    if (!panel) {
      return res.status(404).json({
        success: false,
        error: 'Panel instance not found',
      });
    }

    try {
      const response = await axios.get(`${panel.url}/api/application/nodes`, {
        headers: {
          Accept: 'application/json',
        },
        timeout: 5000,
      });

      panel.status = 'online';
      panel.lastChecked = new Date();
      panel.stats = {
        servers: 0,
        nodes: response.data.data?.length || 0,
        users: 0,
      };

      res.json({
        success: true,
        status: 'online',
        panel: {
          ...panel,
          id: instanceId,
        },
      });
    } catch (error: any) {
      panel.status = 'offline';
      panel.lastChecked = new Date();

      res.json({
        success: true,
        status: 'offline',
        error: error.message || 'Failed to connect',
        panel: {
          ...panel,
          id: instanceId,
        },
      });
    }
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * Get servers from a panel (public API, no auth)
 */
pterodactylRoutes.get('/panels/:instanceId/servers', async (req: any, res: any) => {
  try {
    const { instanceId } = req.params;
    const panel = panels.get(instanceId);

    if (!panel) {
      return res.status(404).json({
        success: false,
        error: 'Panel instance not found',
      });
    }

    try {
      const response = await axios.get(`${panel.url}/api/client/servers`, {
        headers: {
          Accept: 'application/json',
        },
        timeout: 10000,
      });

      res.json({
        success: true,
        servers: response.data.data || [],
      });
    } catch (error: any) {
      res.status(error.response?.status || 500).json({
        success: false,
        error: error.message || 'Failed to fetch servers',
      });
    }
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * Get server details
 */
pterodactylRoutes.get('/panels/:instanceId/servers/:serverId', async (req: any, res: any) => {
  try {
    const { instanceId, serverId } = req.params;
    const panel = panels.get(instanceId);

    if (!panel) {
      return res.status(404).json({
        success: false,
        error: 'Panel instance not found',
      });
    }

    try {
      const response = await axios.get(`${panel.url}/api/client/servers/${serverId}`, {
        headers: {
          Accept: 'application/json',
        },
        timeout: 10000,
      });

      res.json({
        success: true,
        server: response.data.attributes || response.data,
      });
    } catch (error: any) {
      res.status(error.response?.status || 500).json({
        success: false,
        error: error.message || 'Failed to fetch server details',
      });
    }
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * Get server resources (CPU, Memory, Disk)
 */
pterodactylRoutes.get('/panels/:instanceId/servers/:serverId/resources', async (req: any, res: any) => {
  try {
    const { instanceId, serverId } = req.params;
    const panel = panels.get(instanceId);

    if (!panel) {
      return res.status(404).json({
        success: false,
        error: 'Panel instance not found',
      });
    }

    try {
      const response = await axios.get(`${panel.url}/api/client/servers/${serverId}/resources`, {
        headers: {
          Accept: 'application/json',
        },
        timeout: 10000,
      });

      res.json({
        success: true,
        resources: response.data.attributes || response.data,
      });
    } catch (error: any) {
      res.status(error.response?.status || 500).json({
        success: false,
        error: error.message || 'Failed to fetch server resources',
      });
    }
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * Remove a panel instance
 */
pterodactylRoutes.delete('/panels/:instanceId', (req: any, res: any) => {
  try {
    const { instanceId } = req.params;

    if (!panels.has(instanceId)) {
      return res.status(404).json({
        success: false,
        error: 'Panel instance not found',
      });
    }

    panels.delete(instanceId);

    res.json({
      success: true,
      message: 'Panel instance removed',
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});
