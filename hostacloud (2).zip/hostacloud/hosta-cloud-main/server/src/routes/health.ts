import express from 'express';

export const healthRoutes: any = express.Router();

healthRoutes.get('/', (req: any, res: any) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
  });
});
