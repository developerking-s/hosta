import express from 'express';

export const vpsRoutes: any = express.Router();

/**
 * Get free VPS options from GratisVPS
 */
vpsRoutes.get('/providers/gratisvps', async (req: any, res: any) => {
  try {
    // GratisVPS doesn't have a public API, so we return hardcoded info
    const vpsOptions = [
      {
        name: 'GratisVPS',
        url: 'https://gratisvps.net',
        specs: {
          cpu: '2 vCores',
          memory: '512MB - 2GB',
          disk: '10GB - 30GB',
          bandwidth: 'unlimited',
        },
        features: ['Ubuntu/Debian', 'Root Access', 'No Credit Card'],
        status: 'available',
      },
    ];

    res.json({
      success: true,
      provider: 'gratisvps',
      options: vpsOptions,
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * Get free VPS options from VPSFree
 */
vpsRoutes.get('/providers/vpsfree', async (req: any, res: any) => {
  try {
    const vpsOptions = [
      {
        name: 'VPSFree',
        url: 'https://vpsfree.org',
        specs: {
          cpu: '2-4 vCores',
          memory: '1GB - 4GB',
          disk: '20GB - 100GB',
          bandwidth: 'unlimited',
        },
        features: ['Czech Location', 'Root Access', 'Free Forever', 'SSD'],
        status: 'available',
      },
    ];

    res.json({
      success: true,
      provider: 'vpsfree',
      options: vpsOptions,
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * Get all free VPS providers
 */
vpsRoutes.get('/providers', async (req: any, res: any) => {
  try {
    const providers = [
      {
        id: 'gratisvps',
        name: 'GratisVPS',
        url: 'https://gratisvps.net',
        country: 'Multiple',
        description: 'Free VPS hosting with multiple locations',
        specs: {
          cpu: '2 vCores',
          memory: '512MB - 2GB',
          disk: '10GB - 30GB',
        },
        rating: 4.2,
      },
      {
        id: 'vpsfree',
        name: 'VPSFree',
        url: 'https://vpsfree.org',
        country: 'Czech Republic',
        description: 'Free VPS with lifetime service',
        specs: {
          cpu: '2-4 vCores',
          memory: '1GB - 4GB',
          disk: '20GB - 100GB',
        },
        rating: 4.5,
      },
      {
        id: 'oracle-cloud',
        name: 'Oracle Cloud',
        url: 'https://www.oracle.com/cloud/free/',
        country: 'Multiple',
        description: 'Always free cloud resources',
        specs: {
          cpu: '2 vCores',
          memory: '1GB',
          disk: '25GB',
        },
        rating: 4.7,
      },
      {
        id: 'aws-free',
        name: 'AWS Free Tier',
        url: 'https://aws.amazon.com/free/',
        country: 'Multiple',
        description: 'Free EC2 instances for 12 months',
        specs: {
          cpu: '2 vCores',
          memory: '1GB',
          disk: '30GB',
        },
        rating: 4.6,
      },
      {
        id: 'google-cloud',
        name: 'Google Cloud Free',
        url: 'https://cloud.google.com/free',
        country: 'Multiple',
        description: 'Free GCP resources',
        specs: {
          cpu: '2 vCores',
          memory: '1GB',
          disk: '30GB',
        },
        rating: 4.5,
      },
    ];

    res.json({
      success: true,
      total: providers.length,
      providers,
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * Get server resources for a monitoring dashboard
 */
vpsRoutes.get('/monitoring/example', (req: any, res: any) => {
  // Mock data for demonstration
  const mockMonitoring = {
    servers: [
      {
        id: '1',
        name: 'Web Server 1',
        ip: '192.168.1.100',
        provider: 'gratisvps',
        status: 'online',
        cpu: { used: 45, total: 100 },
        memory: { used: 1024, total: 2048 },
        disk: { used: 15, total: 30 },
        uptime: '45 days',
      },
      {
        id: '2',
        name: 'Database Server',
        ip: '192.168.1.101',
        provider: 'vpsfree',
        status: 'online',
        cpu: { used: 65, total: 100 },
        memory: { used: 2048, total: 4096 },
        disk: { used: 45, total: 100 },
        uptime: '32 days',
      },
    ],
  };

  res.json({
    success: true,
    data: mockMonitoring,
  });
});
