/// <reference types="node" />

declare global {
  interface Console {
    log(...args: any[]): void;
    error(...args: any[]): void;
    warn(...args: any[]): void;
    info(...args: any[]): void;
  }
  
  interface ProcessEnv {
    NODE_ENV?: string;
    PORT?: string;
    CORS_ORIGIN?: string;
    PTERODACTYL_INSTANCES?: string;
    SUPABASE_URL?: string;
    SUPABASE_KEY?: string;
  }

  interface Process {
    env: ProcessEnv;
    uptime(): number;
  }

  var URL: typeof URL;
  var process: Process;
  var console: Console;
}

declare const URL: {
  new(url: string): URL;
  prototype: URL;
};

interface URL {
  href: string;
  protocol: string;
  username: string;
  password: string;
  host: string;
  hostname: string;
  port: string;
  pathname: string;
  search: string;
  hash: string;
  readonly origin: string;
  readonly searchParams: URLSearchParams;
  toString(): string;
  toJSON(): string;
}

export {};
